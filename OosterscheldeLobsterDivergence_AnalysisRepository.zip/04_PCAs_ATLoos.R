# ----------------- #
#
# 2. PCA using all European lobster samples across all loci (neutral then outliers)
#
# ----------------- #

# In RStudio set working directory to the path where this R script is located
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# clear Global Environment
rm(list=ls(all=TRUE))

## Load packages
libs = c("adegenet","ggplot2","RColorBrewer","pegas","poppr","miscTools","stringr","FactoMineR","hierfstat")
lapply(libs, library, character.only=TRUE)

################################

# Perform quick PCAs to check what structure is visible at this resolution
# If PCAs show divergence, this is more robust than using DAPCs...

# Perform quick PCAs - dudi.pca needs us to impute means for missing data

# 1 Neutral Loci

# load neutral SNP dataset with filtered Atlantic samples  
load("NeutralData_188i6154s27p.RData")

neutral.ATLoos
# 188 inds, 27pops, 6154 loci 
# (full dataset of loci minus 31 outliers detected by Bayescan or Outflank @p=0.01; individuals cut at 25% missing data)

# Perform quick PCAs - albeit we will need to deal with missing data downstream...
quickpca_neut = PCA(neutral.ATLoos)
plot(quickpca_neut)


# 2 Outlier Loci

load("OutlierData_31snpsOFKorBAY_188i31s27p.RData")

outlier.ATLoos <- outlier.data.overlapATLoos
outlier.ATLoos
# 188 inds, 27pops, 31 loci 
# (only 31 loci flagged as outliers by Bayescan and/or Outflank @p=0.01; individuals cut at 25% missing data)

# Perform quick PCAs - dudi.pca will impute means for missing data
quickpca_out = PCA(outlier.ATLoos)
plot(quickpca_out)
# Oosterschelde still mostly outlying on Dim2 - interesting Atlantic cline results on Dim1?
?PCA

############################################################################################

####  Conduct proper PCA (with NAs attributed mean values) and visualise PCA results...  ###

############################################################################################

# 1 Neutral loci first.

# Replace missing data with the mean allele frequencies
data_neut = tab(neutral.ATLoos, NA.method = "mean")

pca_neut = dudi.pca(data_neut, scannf = FALSE, scale = TRUE, nf = 3)

# Analyse how much percent of genetic variance is explained by each axis
percent = pca_neut$eig/sum(pca_neut$eig)*100
barplot(percent, ylab = "Genetic variance explained by eigenvectors (%)", ylim = c(0,12),
        names.arg = round(percent, 1))
# all ~/<1%...


# Create a data.frame containing individual coordinates
ind_coords = as.data.frame(pca_neut$li)

# Rename columns of dataframe
colnames(ind_coords) = c("Axis1","Axis2","Axis3")

# Add a column containing individuals
ind_coords$Ind = indNames(neutral.ATLoos) # fails to find on data_neut table object; tried genind instead?

# Add a column with the site IDs
ind_coords$Site = neutral.ATLoos$pop   # fails to find on data_neut table object; tried genind instead?


# Calculate centroid (average) position for each population
centroid = aggregate(cbind(Axis1, Axis2, Axis3) ~ Site, data = ind_coords, FUN = mean)

# Add centroid coordinates to ind_coords dataframe
ind_coords = left_join(ind_coords, centroid, by = "Site", suffix = c("",".cen"))

# Custom x and y labels
xlab = paste("Axis 1 (", format(round(percent[1], 1), nsmall=1)," %)", sep="")
ylab = paste("Axis 2 (", format(round(percent[2], 1), nsmall=1)," %)", sep="")

# Custom theme for ggplot2
ggtheme = theme(legend.title = element_blank(),
                axis.text.y = element_text(colour="black", size=12),
                axis.text.x = element_text(colour="black", size=12),
                axis.title = element_text(colour="black", size=12),
                panel.border = element_rect(colour="black", fill=NA, linewidth=1),
                panel.background = element_blank(),
                plot.title = element_text(hjust=0.5, size=15),
                legend.position = "top",
                legend.text = element_text(size=12),
                legend.key.size = unit(0.7,"cm"),
                legend.box.spacing = unit(0, "cm")
)

ind_coords

# Scatter plot axis 1 vs. 2
pcaplot_neut <- ggplot(data = ind_coords, aes(x = Axis1, y = Axis2))+
                 geom_hline(yintercept = 0)+
                 geom_vline(xintercept = 0)+
             # spider segments
                 geom_segment(aes(xend = Axis1.cen, yend = Axis2.cen, colour = Site), show.legend = FALSE)+
             # points
                 geom_point(aes(fill = Site), shape = 21, size = 3, show.legend = FALSE)+
             # centroids
                 geom_label(data = centroid, aes(label = Site, fill = Site), size = 4, show.legend = FALSE)+
             # colouring
                #scale_fill_manual(values = cols)+
                #scale_colour_manual(values = cols)+
            # custom labels
                 labs(x = xlab, y = ylab)+
                 ggtitle("Lobster PCA")+
            # custom theme
                 ggtheme

pcaplot_neut
# Atlantic cline potentially still visible on Dim2 - so adjust colours to regional clusters...

# edit colours to regional clusters...

## Function to add region labels to population labels
summary(neutral.ATLoos$pop)
addregionATL.K3 = function(x){
  # If pop label is present function will output the country
  if(x=="Oos") y = " Oosterschelde "
  if(x=="Tan"|x=="Pen"|x=="Vig"|
     x=="Idr"|x=="Bre"|x=="Eye"|x=="Mul"|x=="Ven"|
     x=="Jer"|x=="Loo"|x=="Sbs"|x=="Ios"|x=="Don"|
     x=="Kil"|x=="Cor"|x=="Iom"|x=="Pem"|x=="Pad"|
     x=="Heb"|x=="Ork"|x=="She"|x=="Brd"|x=="Cro") y = " Atlantic "
  if(x=="Hel"|x=="Flo"|x=="Lys"|x=="Ber"|x=="Tro"|x=="Sin") y = " Scandinavia "
  return(y)
}

ind_coords$region = sapply(ind_coords$Site, addregionATL.K3) 
unique(ind_coords$region)

## Reorder levels for plotting
ind_coords$region = factor(ind_coords$region, 
                              levels=c( " Atlantic ",
                                        " Scandinavia ",
                                        " Oosterschelde "
                              ))

## Calculate centroid position for each population
centroidneut = aggregate(cbind(Axis1, Axis2, Axis3) ~ Site, data=ind_coords, FUN=mean)
centroidneut$region = sapply(centroidneut$Site, addregionATL.K3)
centroidneut$region

names(ind_coords)
## Find and store coordinate info required to draw segments
segsneut = merge(ind_coords, setNames(centroidneut, 
                                         c("Site","Axis1.cen","Axis2.cen","Axis3.cen")),
                 by = "Site", sort = FALSE)

## Colour Brewer definitions
colsATLK3 = c("dodgerblue","purple","red")


# Scatter plot axis 1 vs. 2
pcaplot_neut_regions <- ggplot(data = ind_coords, aes(x = Axis1, y = Axis2))+
  geom_hline(yintercept = 0)+
  geom_vline(xintercept = 0)+
  # spider segments
  geom_segment(aes(xend = Axis1.cen, yend = Axis2.cen, colour = region), show.legend = FALSE)+
  # points
  geom_point(aes(fill = region), shape = 21, size = 3, show.legend = TRUE)+
  # centroids
  geom_label(data = centroidneut, aes(label = Site, fill = region), size = 4, show.legend = FALSE)+
  # colouring
  scale_fill_manual(values = colsATLK3)+
  scale_colour_manual(values = colsATLK3)+
  # custom labels
  labs(x = xlab, y = ylab)+
  #ggtitle("Lobster PCA")+
  # custom theme
  ggtheme+
  guides(fill=guide_legend(nrow=1, byrow=TRUE))

pcaplot_neut_regions

# Export plot
ggsave("PCA_neutral_188i27p6154snps.png", width = 8, height = 6, dpi = 600)


###############################

############################################################################################################################

###############################


# 2 Outlier Loci



# Replace missing data with the mean allele frequencies
data_out = tab(outlier.ATLoos, NA.method = "mean")

pca_out = dudi.pca(data_out, scannf = FALSE, scale = TRUE, nf = 3)

# Analyse how much percent of genetic variance is explained by each axis
percent_out = pca_out$eig/sum(pca_out$eig)*100
barplot(percent_out, ylab = "Genetic variance explained by eigenvectors (%)", ylim = c(0,50),
        names.arg = round(percent_out, 1))
# some large PC1 = 46.8%, PC2 = ~22%, PC3 = 5.8% ... 


# Create a data.frame containing individual coordinates
ind_coords_out = as.data.frame(pca_out$li)

# Rename columns of dataframe
colnames(ind_coords_out) = c("Axis1","Axis2","Axis3")

# Add a column containing individuals
ind_coords_out$Ind = indNames(outlier.ATLoos) # fails to find on data_neut table object; tried genind instead?

# Add a column with the site IDs
ind_coords_out$Site = outlier.ATLoos$pop   # fails to find on data_neut table object; tried genind instead?


# Calculate centroid (average) position for each population
centroid_out = aggregate(cbind(Axis1, Axis2, Axis3) ~ Site, data = ind_coords_out, FUN = mean)

# Add centroid coordinates to ind_coords dataframe
ind_coords_out = left_join(ind_coords_out, centroid_out, by = "Site", suffix = c("",".cen"))

# Custom x and y labels
xlab = paste("Axis 1 (", format(round(percent_out[1], 1), nsmall=1)," %)", sep="")
ylab = paste("Axis 2 (", format(round(percent_out[2], 1), nsmall=1)," %)", sep="")

# Custom theme for ggplot2
ggtheme = theme(legend.title = element_blank(),
                axis.text.y = element_text(colour="black", size=12),
                axis.text.x = element_text(colour="black", size=12),
                axis.title = element_text(colour="black", size=12),
                panel.border = element_rect(colour="black", fill=NA, linewidth=1),
                panel.background = element_blank(),
                plot.title = element_text(hjust=0.5, size=15),
                legend.position = "top",
                legend.text = element_text(size=12),
                legend.key.size = unit(0.7,"cm"),
                legend.box.spacing = unit(0, "cm")
)

ind_coords_out

# Scatter plot axis 1 vs. 2
pcaplot_out <- ggplot(data = ind_coords_out, aes(x = Axis1, y = Axis2))+
  geom_hline(yintercept = 0)+
  geom_vline(xintercept = 0)+
  # spider segments
  geom_segment(aes(xend = Axis1.cen, yend = Axis2.cen, colour = Site), show.legend = FALSE)+
  # points
  geom_point(aes(fill = Site), shape = 21, size = 3, show.legend = FALSE)+
  # centroids
  geom_label(data = centroid_out, aes(label = Site, fill = Site), size = 4, show.legend = FALSE)+
  # colouring
  #scale_fill_manual(values = cols)+
  #scale_colour_manual(values = cols)+
  # custom labels
  labs(x = xlab, y = ylab)+
  ggtitle("Lobster PCA")+
  # custom theme
  ggtheme

pcaplot_out
# Wow - Morocco sample (Tan) pulls away 
# By sample means, outliers depict UK North Sea as mixing zone between W UK and Scandi, with Oos and Hel bridging UK N Sea and Scandi 
# Atlantic cline powering a lot of this - but not the separation of Oosterschelde that DAPC generates.

# check PC1 vs PC3

# Scatter plot axis 1 vs. 2
pcaplot_out13 <- ggplot(data = ind_coords_out, aes(x = Axis1, y = Axis3))+
  geom_hline(yintercept = 0)+
  geom_vline(xintercept = 0)+
  # spider segments
  geom_segment(aes(xend = Axis1.cen, yend = Axis3.cen, colour = Site), show.legend = FALSE)+
  # points
  geom_point(aes(fill = Site), shape = 21, size = 3, show.legend = FALSE)+
  # centroids
  geom_label(data = centroid_out, aes(label = Site, fill = Site), size = 4, show.legend = FALSE)+
  # colouring
  #scale_fill_manual(values = cols)+
  #scale_colour_manual(values = cols)+
  # custom labels
  labs(x = xlab, y = ylab)+
  ggtitle("Lobster PCA")+
  # custom theme
  ggtheme

pcaplot_out13
# a few slightly more outlying Oosterschelde inidividuals here, but nothing much more...

# strange, as basic quick PCA definitely seemed to segregate most OOS samples...
plot(quickpca_out)

?dudi.pca
#### VISUALISE PCA FOR PUBLICATION FIGURE

# edit colours to regional clusters...

## Function to add region labels to population labels
summary(outlier.ATLoos$pop)
addregionATL.K6 = function(x){
  # If pop label is present function will output the country
  if(x=="Oos") y = " Oosterschelde "
  if(x=="Pen"|x=="Vig") y = " Iberia "
  if(x=="Tan") y = " Morocco "
  if(x=="Idr"|x=="Bre"|x=="Mul"|x=="Ven"|
     x=="Jer"|x=="Loo"|x=="Ios"|x=="Don"|
     x=="Kil"|x=="Cor"|x=="Iom"|x=="Pem"|x=="Pad"|
     x=="Sbs"|x=="Heb"|x=="Ork"|x=="She") y = " W Britain/France "
  if(x=="Eye"|x=="Brd"|x=="Cro") y = " E Britain  "
  if(x=="Hel"|x=="Flo"|x=="Lys"|x=="Ber"|x=="Tro"|x=="Sin") y = " Scandinavia "
  return(y)
}

ind_coords_out$region = sapply(ind_coords_out$Site, addregionATL.K6) 
unique(ind_coords_out$region)

## Reorder levels for plotting
ind_coords_out$region = factor(ind_coords_out$region, 
                           levels=c( " Morocco ",
                                     " Iberia ",
                                     " W Britain/France ",
                                     " E Britain  ",
                                     " Scandinavia ",
                                     " Oosterschelde "
                           ))

## Calculate centroid position for each population
centroid_out = aggregate(cbind(Axis1, Axis2, Axis3) ~ Site, data=ind_coords_out, FUN=mean)
centroid_out$region = sapply(centroid_out$Site, addregionATL.K6)
centroid_out$region

names(ind_coords_out)
## Find and store coordinate info required to draw segments
segs_out = merge(ind_coords_out, setNames(centroid_out, 
                                      c("Site","Axis1.cen","Axis2.cen","Axis3.cen")),
                 by = "Site", sort = FALSE)

## Colour Brewer definitions
colsATLK6 = c("aquamarine","cyan","dodgerblue","slateblue","purple","red")


# Scatter plot axis 1 vs. 2
pcaplot_outliers_regions <- ggplot(data = ind_coords_out, aes(x = Axis1, y = Axis2))+
  geom_hline(yintercept = 0)+
  geom_vline(xintercept = 0)+
  # spider segments
  geom_segment(aes(xend = Axis1.cen, yend = Axis2.cen, colour = region), show.legend = FALSE)+
  # points
  geom_point(aes(fill = region), shape = 21, size = 3, show.legend = TRUE)+
  # centroids
  geom_label(data = centroid_out, aes(label = Site, fill = region), size = 4, show.legend = FALSE)+
  # colouring
  scale_fill_manual(values = colsATLK6)+
  scale_colour_manual(values = colsATLK6)+
  # custom labels
  labs(x = xlab, y = ylab)+
  #ggtitle("Lobster PCA")+
  # custom theme
  ggtheme+
  guides(fill=guide_legend(nrow=2, byrow=TRUE))

pcaplot_outliers_regions

# Export plot
ggsave("PCA_outliers_188i27p31snps.png", width = 8, height = 6, dpi = 600)

plot(quickpca_out)
###############################


###############################
