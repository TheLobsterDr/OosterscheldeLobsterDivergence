# New script to test how many loci are polymorphic by population in main ATL-Oos dataset
# Probably a much easier way of doing this, but I don't know it! 
 
# In RStudio set working directory to the path where this R script is located
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# clear Global Environment
rm(list=ls(all=TRUE))

## Load packages
libs = c("adegenet","ggplot2","RColorBrewer","pegas","poppr","miscTools","stringr","FactoMineR","hierfstat","diveRsity","graph4lg")
lapply(libs, library, character.only=TRUE)

################################

load(file = "ATLoos_fullpoly_188i-6185s-27p.RData")
data_filt
summary(data_filt$pop)

################################

### use isPoly to test individual samples for SNP diversity

################################

## How many loci polymorphic in a pop? 

# 6) Oosterschelde (6 in pop order, NE-SW)
#?isPoly
oos_data <- popsub(data_filt, sublist=c("Oos"))
oos_data

oos_poly <- isPoly(oos_data) 
summary(oos_poly)
#   Mode   FALSE    TRUE 
#logical    3451    2734 

# so 3451 loci aren't actually SNPs in Oos with this dataset (no variant alleles present)!!!

################################

# how does this compare to other stocks??
summary(data_filt$pop)

################################

# 1) Tro 
tro_data <- popsub(data_filt, sublist=c("Tro"))
tro_data
tro_poly <- isPoly(tro_data) 
summary(tro_poly)
#    Mode   FALSE    TRUE 
#logical    4026    2155 

# 2) Ber
ber_data <- popsub(data_filt, sublist=c("Ber"))
ber_poly <- isPoly(ber_data) 
summary(ber_poly)
#Mode   FALSE    TRUE 
#logical    3371    2814 

# 3) Flo
flo_data <- popsub(data_filt, sublist=c("Flo"))
flo_poly <- isPoly(flo_data) 
summary(flo_poly)
#   Mode   FALSE    TRUE 
#logical    2838    3347 

# 4) Lys
lys_data <- popsub(data_filt, sublist=c("Lys"))
lys_poly <- isPoly(lys_data) 
summary(lys_poly)
#   Mode   FALSE    TRUE 
#logical    2398    3787 

# 5) Hel
hel_data <- popsub(data_filt, sublist=c("Hel"))
hel_poly <- isPoly(hel_data) 
summary(hel_poly)
#   Mode   FALSE    TRUE 
#logical    2398    3787 

# 7) cro
cro_data <- popsub(data_filt, sublist=c("Cro"))
cro_poly <- isPoly(cro_data) 
summary(cro_poly)
#   Mode   FALSE    TRUE 
#logical    2961    3224

# 8) brd
brd_data <- popsub(data_filt, sublist=c("Brd"))
brd_poly <- isPoly(brd_data) 
summary(brd_poly)
#   Mode   FALSE    TRUE 
#logical    2875    3310 

# 9) eye
eye_data <- popsub(data_filt, sublist=c("Eye"))
eye_poly <- isPoly(eye_data) 
summary(eye_poly)
#Mode   FALSE    TRUE 
#logical    3103    3082 

# 10) she
she_data <- popsub(data_filt, sublist=c("She"))
she_poly <- isPoly(she_data) 
summary(she_poly)
#   Mode   FALSE    TRUE 
#logical    2921    3264 

# 11) ork
ork_data <- popsub(data_filt, sublist=c("Ork"))
ork_poly <- isPoly(ork_data) 
summary(ork_poly)
#   Mode   FALSE    TRUE 
#logical    3275    2910

# 12) heb
heb_data <- popsub(data_filt, sublist=c("Heb"))
heb_poly <- isPoly(heb_data) 
summary(heb_poly)
#   Mode   FALSE    TRUE 
#logical    3332    2853

# 13) iom
iom_data <- popsub(data_filt, sublist=c("Iom"))
iom_poly <- isPoly(iom_data) 
summary(iom_poly)
#   Mode   FALSE    TRUE 
#logical    3137    3048 

# 14) don
don_data <- popsub(data_filt, sublist=c("Don"))
don_poly <- isPoly(don_data) 
summary(don_poly)
#   Mode   FALSE    TRUE 
#logical    2687    3498

# 15) kil
kil_data <- popsub(data_filt, sublist=c("Kil"))
kil_poly <- isPoly(she_data) 
summary(kil_poly)
#   Mode   FALSE    TRUE 
#logical    2921    3264

# 16) cor
cor_data <- popsub(data_filt, sublist=c("Cor"))
cor_poly <- isPoly(cor_data) 
summary(cor_poly)
#   Mode   FALSE    TRUE 
#logical    2615    3570 


# 17) pem 
pem_data <- popsub(data_filt, sublist=c("Pem"))
pem_poly <- isPoly(pem_data) 
summary(pem_poly)
#   Mode   FALSE    TRUE 
#logical    3191    2994 

# 18) pad
pad_data <- popsub(data_filt, sublist=c("Pad"))
pad_poly <- isPoly(pad_data) 
summary(pad_poly)
#   Mode   FALSE    TRUE 
#logical    2833    3352

# 19) sbs
sbs_data <- popsub(data_filt, sublist=c("Sbs"))
sbs_poly <- isPoly(sbs_data) 
summary(sbs_poly)
#   Mode   FALSE    TRUE 
#logical    2959    3226 

# 20) loo
loo_data <- popsub(data_filt, sublist=c("Loo"))
loo_poly <- isPoly(loo_data) 
summary(loo_poly)
#   Mode   FALSE    TRUE 
#logical    3639    2546 

# 21) ios
ios_data <- popsub(data_filt, sublist=c("Ios"))
ios_poly <- isPoly(ios_data) 
summary(ios_poly)
#   Mode   FALSE    TRUE 
#logical    3013    3172 

# 22) jer
jer_data <- popsub(data_filt, sublist=c("Jer"))
jer_poly <- isPoly(jer_data) 
summary(jer_poly)
#   Mode   FALSE    TRUE 
#logical    2585    3600

# 23) bre
bre_data <- popsub(data_filt, sublist=c("Bre"))
bre_poly <- isPoly(bre_data) 
summary(bre_poly)
#   Mode   FALSE    TRUE 
#logical    3050    3135

# 24) idr
idr_data <- popsub(data_filt, sublist=c("Idr"))
idr_poly <- isPoly(idr_data) 
summary(idr_poly)
#   Mode   FALSE    TRUE 
#logical    3186    2999 

# 25) vig
vig_data <- popsub(data_filt, sublist=c("Vig"))
vig_poly <- isPoly(vig_data) 
summary(vig_poly)
#   Mode   FALSE    TRUE 
#logical    3249    2936 

# 26) pen
pen_data <- popsub(data_filt, sublist=c("Pen"))
pen_poly <- isPoly(pen_data) 
summary(pen_poly)
#   Mode   FALSE    TRUE 
#logical    3143    3042 

# 27) tan
tan_data <- popsub(data_filt, sublist=c("Tan"))
tan_poly <- isPoly(tan_data) 
summary(tan_poly)
#   Mode   FALSE    TRUE 
#logical    3072    3113

# manually copy values to spreadsheet

# # # # # # # # -------- !  END  ! -------- # # # # # # # #
