# =============================================================
#
# 3 - Idenitfy outlier loci using Bayescan, OutFlank & PCadapt  
#
# =============================================================

# set session to working directory (source file)
rm(list=ls(all=TRUE))

## Load packages
lib2 = c("ade4","RColorBrewer","adegenet","seqinr","poppr","ggplot2","mmod",
         "pegas","plyr","hierfstat","diveRsity","dartR", "genetics", "genepop",
         "pcadapt","vcfR","viridis","VennDiagram")
lapply(lib2, library, character.only=TRUE)

# ----------------- #

# ----------------- #
#
# A) BayeScan (using prior_odds 10,000)
#
# ----------------- #

### Run Bayescan in ISCA and import data back to R for analysis

### first, export the genind (as sampled) in Bayescan-compatible format

load("ATLoos_fullpoly_188i-6185s-27p.RData")

data_filt
summary(data_filt$pop)

dat.BAYfull = genind2hierfstat(dat = data_filt)
write.bayescan(dat = dat.BAYfull, diploid = TRUE, fn = "inputbayescan_ATLoos_188i6185s27p.txt")

### Copy inputs to ISCA directory with Bayescan and run in there
### ./bayescan_2.1 bayescan_input.txt -od . -o bayescan_output -pr_odds 10000 -threads 8

### once run, copy all the output files into R working directory


### A1) Full dataset analysis - locations as sampled (K=27)


## Run Bayescan plot function
source("plot_bayescan_function.txt")
ATLoosBAYresults = plot_bayescan("BaysOut_ATLoos_188i6185s27p_fst.txt", FDR=0.05)
# manual export of plot

ATLoosBAYresults$nb_outliers
# 21 outliers
ATLoosBAYresults$outliers
# list of the 21 outlier locus numbers (bayescan #s not genind locus IDs)

## Which locus IDs are outliers? convert bayescan locus #s back to genind loc IDs
ATLoos.out.bay = locNames(data_filt)[ATLoosBAYresults$outliers]
ATLoos.out.bay
# list of 21 outlier loci IDs via Bayescan 27 Atlantic pop priors as sampled

# save the list of outlier loci to .csv 
write.csv(ATLoos.out.bay, file="21outliersBAY_ATLoos_188i27p.csv")

#create new genind with just the Bayescan outlier loci
BAYoutlier.ATLoos <- (data_filt[loc = ATLoos.out.bay])
BAYoutlier.ATLoos
summary(BAYoutlier.ATLoos$pop)

## Save and output this filtered genind object
title.outliers.ATLoos = paste("OutlierData_BAYATLoos_",
                                    nInd(BAYoutlier.ATLoos),"i", 
                                    nLoc(BAYoutlier.ATLoos),"s",
                                    nPop(BAYoutlier.ATLoos),"p.RData",sep="")
title.outliers.ATLoos
save(BAYoutlier.ATLoos, file=title.outliers.ATLoos)
# saves genind object and shows number of samples / snps / pops


### A2) Full dataset analysis - locations as sampled (K=2)

# re-run DAPC outlier script etc with 21 loci

load("ATLoos_fullpoly_188i-6185s-2p.RData")
data_K2_filt
summary(data_K2_filt$pop)

dat.BAYfull_K2 = genind2hierfstat(dat = data_K2_filt)
write.bayescan(dat = dat.BAYfull_K2, diploid = TRUE, fn = "inputbayescan_ATLoos_188i6185s2p.txt")

### Copy inputs to ISCA directory with Bayescan and run in there
### ./bayescan_2.1 bayescan_input.txt -od . -o bayescan_output -pr_odds 10000 -threads 8

### once run, copy all the output files into R working directory

## Run Bayescan plot function
source("plot_bayescan_function.txt")
ATLoosK2_BAYresults = plot_bayescan("BaysOut_ATLoos_188i6185s2p_fst.txt", FDR=0.05)
# manual export of plot

ATLoosK2_BAYresults$nb_outliers
# 0 outliers



## ============================================

## B - Outflank

## ============================================

# --------------------------------------------------------------
# Run without DAPC structure (i.e. priors as pops as sampled) to match Bayescan & PCadapt
# --------------------------------------------------------------

## Run OutFLANK using dartR wrapper script
ATLoos.outflnk05 = gl.outflank(data_filt, qthreshold = 0.05)

## Outliers
ATLoos.outflnk05 = ATLoos.outflnk05$outflank$results
summary(ATLoos.outflnk05)

## Remove duplicated rows for each SNP
toRemove = seq(1, nrow(ATLoos.outflnk05), by=2)
ATLoos.outflnk05 = ATLoos.outflnk05[-toRemove, ]
summary(ATLoos.outflnk05)

## Plot He verus Fst
plot(ATLoos.outflnk05$He, ATLoos.outflnk05$FST, pch=20, col="black")
# NEED THIS PLOT BUT WITH OUTLIERS FLAGGED IN RED... (not sure what Fst cutoff is sig?)
# ASK TJENKS?!?!

## Get indexes for outliers
out_index.OFKATLoos05 = which(ATLoos.outflnk05$OutlierFlag==TRUE)
out_index.OFKATLoos05
### 41 outliers (p=0.05) detected by OutFlank with pop priors as sampled

# Convert the index to find the names of the loci involved
ATLoos.out.outflnk05 = locNames(data_filt)[out_index.OFKATLoos05]
ATLoos.out.outflnk05
### these are 41 outlier loci locus IDs (Outflank set at p0.05)

# save the list of these 101 outlier loci to .csv 
write.csv(ATLoos.out.outflnk05, file="41outliersOFK_ATLoosp05.csv")

#create new genind with just the outlier loci
OFKoutlier.data.ATLoosp05 <- (data_filt[loc = ATLoos.out.outflnk05])
OFKoutlier.data.ATLoosp05
nLoc(OFKoutlier.data.ATLoosp05)
nPop(OFKoutlier.data.ATLoosp05)
summary(OFKoutlier.data.ATLoosp05$pop)

## Save and output this filtered genind object

title.OFKdata.ATLoosp05 = paste("OutlierData_OFK_ATLoosp05_",nInd(OFKoutlier.data.ATLoosp05),"i",
                        nLoc(OFKoutlier.data.ATLoosp05),"s",nPop(OFKoutlier.data.ATLoosp05),
                        "p.RData",sep="")
title.OFKdata.ATLoosp05
save(OFKoutlier.data.ATLoosp05, file=title.OFKdata.ATLoosp05)
# saves genind object and shows number of samples / snps / pops

#-------------------------------------------------------------------#


## REPEAT OUTFLANK WITH ONLY HIGHLY SIG OUTLIERS DETECTED (p0.01)

## Run OutFLANK using dartR wrapper script
ATLoos.outflnk01 = gl.outflank(data_filt, qthreshold = 0.01)

## Outliers
ATLoos.outflnk01 = ATLoos.outflnk01$outflank$results
summary(ATLoos.outflnk01)

## Remove duplicated rows for each SNP
toRemove = seq(1, nrow(ATLoos.outflnk01), by=2)
ATLoos.outflnk01 = ATLoos.outflnk01[-toRemove, ]
summary(ATLoos.outflnk01)

## Plot He verus Fst
plot(ATLoos.outflnk01$He, ATLoos.outflnk01$FST, pch=20, col="black")
# NEED THIS PLOT BUT WITH OUTLIERS FLAGGED IN RED... 
# ASK TJENKS?!?!

## Get indexes for outliers
out_index.OFKATLoos01 = which(ATLoos.outflnk01$OutlierFlag==TRUE)
out_index.OFKATLoos01
### 28 outliers (p=0.01) detected by OutFlank with pop priors as sampled
### approx p=0.01 cutoff is loci with Fst of ~0.19.

# Convert the index to find the names of the loci involved
ATLoos.out.outflnk01 = locNames(data_filt)[out_index.OFKATLoos01]
ATLoos.out.outflnk01
### these are 28 outlier loci locus IDs (Outflank set at p0.01)

# save the list of these 101 outlier loci to .csv 
write.csv(ATLoos.out.outflnk01, file="28outliersOFK_ATLoos-p01.csv")

#create new genind with just the outlier loci
OFKoutlier.data.ATLoosp01 <- (data_filt[loc = ATLoos.out.outflnk01])
OFKoutlier.data.ATLoosp01
nLoc(OFKoutlier.data.ATLoosp01)
nPop(OFKoutlier.data.ATLoosp01)
summary(OFKoutlier.data.ATLoosp01$pop)

## Save and output this filtered genind object

title.OFKdata.ATLoosp01 = paste("OutlierData_OFK_ATLoos-p01_",nInd(OFKoutlier.data.ATLoosp01),"i",
                              nLoc(OFKoutlier.data.ATLoosp01),"s",nPop(OFKoutlier.data.ATLoosp01),
                              "p.RData",sep="")
title.OFKdata.ATLoosp01
save(OFKoutlier.data.ATLoosp01, file=title.OFKdata.ATLoosp01)
# saves genind object and shows number of samples / snps / pops


##############################################################################################
# REPEAT USING A K2 DATASET - OOSTERSCHELDE VS ALL OTHER ATLANTIC SAMPLES GROUPED AS ONE POP #
##############################################################################################

## Run OutFLANK using dartR wrapper script
ATLoos_K2.outflnk01 = gl.outflank(data_K2_filt, qthreshold = 0.01)

## Outliers
ATLoos_K2.outflnk01 = ATLoos_K2.outflnk01$outflank$results
summary(ATLoos_K2.outflnk01)

## Remove duplicated rows for each SNP
toRemove = seq(1, nrow(ATLoos_K2.outflnk01), by=2)
ATLoos_K2.outflnk01 = ATLoos_K2.outflnk01[-toRemove, ]
summary(ATLoos_K2.outflnk01)

## Plot He verus Fst
plot(ATLoos_K2.outflnk01$He, ATLoos_K2.outflnk01$FST, pch=20, col="black")
# NEED THIS PLOT BUT WITH OUTLIERS FLAGGED IN RED... 
# ASK TJENKS?!?!

## Get indexes for outliers
out_index.OFKATLoos01_K2 = which(ATLoos_K2.outflnk01$OutlierFlag==TRUE)
out_index.OFKATLoos01_K2
### zero outliers (p=0.01) detected by OutFlank with pop priors as sampled




######################++++++++++++++++++++++++++++++++++++#############################################

#### Check for overlap between the two outlier datasets with a Venn Diagram

# Now use the bayescan loci in a vector
length(ATLoos.out.bay)
# 21 bayescan outliers 

# And save outflank outliers as a vector
length(ATLoos.out.outflnk01)
# 28 highly sig outflank outliers 
length(ATLoos.out.outflnk05)
# 41 sig outflank outliers

# Create Venn diagrams of these two tests
#venn.diagram

# Outflank-p0.05 vs Bayescan:
venn.diagram(
  x = list(ATLoos.out.bay,ATLoos.out.outflnk05),
  category.names = c("Bayescan" , "Outflank (p0.05)"),
  filename = 'Venn_ATLoos-outliers_OFK05vBAY.png',
  output=TRUE,
  imagetype="png" ,
  height = 500 , 
  width = 500, 
  resolution = 300,
  compression = "lzw",
  col = c ("blue", "red") ,
  cat.cex = 0.6,
  cat.pos = c(0, 0) ,
  cat.col = c("blue", "red"))
  
# Autosaved plot shows that 20 of the 21 Bayescan outliers overlap with 41 Outflank outliers detected at p=0.05 

# Outflank-p0.01 vs Bayescan: (31 outliers in all)
venn.diagram(
  x = list(ATLoos.out.bay,ATLoos.out.outflnk01),
  category.names = c("Bayescan - 21" , "Outflank - 28"),
  filename = 'Venn_ATLoos-outliers_OFK01vBAY.png',
  output=TRUE,
  imagetype="png" ,
  height = 500 , 
  width = 500, 
  resolution = 300,
  compression = "lzw",
  col = c ("blue", "red") ,
  cat.cex = 0.6,
  cat.pos = c(0, 0) ,
  cat.col = c("blue", "red"))

# Autosaved plot shows that 18 of the 21 Bayescan outliers overlap with the 28 Outflank outliers detected at p=0.01 
# 31 outliers in all 

# repeat with only numeric overlap labels for post-processing into figure
venn.diagram(
  x = list(ATLoos.out.bay, ATLoos.out.outflnk01),
  category.names = c("" , ""),
  filename = 'Venn_ATLoos-31outliers_OFK01vBAY_unlabelled.png',
  output=TRUE,
  imagetype="png" ,
  height = 500 , 
  width = 500, 
  resolution = 300,
  compression = "lzw",
  col = c ("blue", "red") ,
  cat.cex = 0.6,
  cat.pos = c(0, 0) ,
  cat.col = c("blue", "red"))

# Create genind of these 31 overlapping loci - .csv created manually
# load csv for vector of locus IDs

ATLoos.out.overlap <- scan(file = "31outlierIDs_BAYorOFKp01.csv", skip = 0, character())
ATLoos.out.overlap

#create new genind with just the outlier loci
outlier.data.overlapATLoos <- (data_filt[loc = ATLoos.out.overlap])
outlier.data.overlapATLoos

## Save and output this filtered genind object

title.outlierdata.overlapATLoos = paste("OutlierData_31snpsOFKorBAY_",nInd(outlier.data.overlapATLoos),"i",
                              nLoc(outlier.data.overlapATLoos),"s",nPop(outlier.data.overlapATLoos),
                              "p.RData",sep="")
title.outlierdata.overlapATLoos
save(outlier.data.overlapATLoos, file=title.outlierdata.overlapATLoos)
# saves genind object and shows number of samples / snps / pops



####### =============================================================== #######


# CREATE NEUTRAL SNP DATASET!!!

# Now save just a 'Neutral' dataset, without these 50 outliers
#create new genind with the Bayescan outlier loci blacklisted!
locIDs = locNames(data_filt)
locIDs
neutralsnps = locIDs[! locIDs %in% ATLoos.out.overlap]
neutralsnps
neutral.ATLoos = data_filt[loc=neutralsnps]
neutral.ATLoos

## Save and output this filtered genind object
title.neutral.ATLoos = paste("NeutralData_",
                             nInd(neutral.ATLoos),"i", 
                             nLoc(neutral.ATLoos),"s",
                             nPop(neutral.ATLoos),"p.RData",sep="")
title.neutral.ATLoos
save(neutral.ATLoos, file=title.neutral.ATLoos)
# saves genind object and shows number of samples / snps / pops



########### 
# ======= #
# ! END ! # 
# ======= #
########### 








#############################################################

#create combo dataset from all 3 Bayescan runs - Full, ATL & MED
# This contains Full x50, Atl x21 (x1 unique), Med x0

BAYcombolob <- readLines("51outliersBAY_FullATLcombo.csv")
BAYcombolob

#create new genind with just the Bayescan outlier loci
fullBAY51 <- (data_filt[loc = BAYcombolob])
fullBAY51
summary(fullBAY51$pop)

save(fullBAY51, file="OutlierData_BAYfullCombo_214ind51snp32pop.RData")
# saves genind object and shows number of samples / snps / pops

#############################################################

# create neutral dataset, with all loci EXCEPT these outliers

# CREATE NEUTRAL SNP DATASET!!!

# Now save just a 'Neutral' dataset, without these 51 outliers
#create new genind with the Bayescan outlier loci blacklisted!
locIDs = locNames(data_filt)
locIDs
neutralsnps = locIDs[! locIDs %in% BAYcombolob]
neutralsnps
neutral.fulldata32pop = data_filt[loc=neutralsnps]
neutral.fulldata32pop

## Save and output this filtered genind object
title.neutral.fullbay32pop = paste("NeutralData_",
                                   nInd(neutral.fulldata32pop),"ind", 
                                   nLoc(neutral.fulldata32pop),"snp",
                                   nPop(neutral.fulldata32pop),"pop.RData",sep="")
title.neutral.fullbay32pop
save(neutral.fulldata32pop, file=title.neutral.fullbay32pop)
# saves genind object and shows number of samples / snps / pops


##########======================================#########

##########======================================#########
## NOW INCORPORATE THE ONE SNP LOCUS FLAGGED BY dbRDA! ##
##########======================================#########

#create combo dataset from all 3 Bayescan runs - Full, ATL & MED
# This contains Full x50, Atl x21 (x1 unique), Med x0

BAYGEAcombolob <- readLines("52outliersBAYFullATLplusGEAcombo.csv")
BAYGEAcombolob

#create new genind with just the Bayescan outlier loci
alloutliers52 <- (data_filt[loc = BAYGEAcombolob])
alloutliers52
nPop(alloutliers52)
nLoc(alloutliers52)
summary(alloutliers52$pop)
# all outliers dataset: 214i 32p  52s

save(alloutliers52, file="OutlierData_AllBayGEA_214ind52snp32pop.RData")
# saves genind object and shows number of samples / snps / pops

#############################################################

# now create neutral dataset, with all loci EXCEPT these outliers

# CREATE NEUTRAL SNP DATASET!!!

# Now save just a 'Neutral' dataset, without these 51 outliers
#create new genind with the Bayescan outlier loci blacklisted!
locIDs = locNames(data_filt)
locIDs
allneutralsnps = locIDs[! locIDs %in% BAYGEAcombolob]
allneutralsnps
neutrallob.fulldata = data_filt[loc=allneutralsnps]
neutrallob.fulldata

## Save and output this filtered genind object
title.neutral.lobdata = paste("NeutralData_",
                                   nInd(neutrallob.fulldata),"ind", 
                                   nLoc(neutrallob.fulldata),"snp",
                                   nPop(neutrallob.fulldata),"pop.RData",sep="")
title.neutral.lobdata
save(neutrallob.fulldata, file=title.neutral.lobdata)
# saves genind object and shows number of samples / snps / pops


