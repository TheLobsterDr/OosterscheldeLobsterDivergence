###--------------------------------------------
# Charlie Ellis, European Lobster RADseq 2020 (code adapted from T Jenkins)
# STAGE 1
# Initial import of Full Range clawed lobster RADseq denovo data using genepop file created by Stacks
# Conversion of .gen file to a genind object
# Filtering to remove loci and individuals suffering missing data
# initial PCA to explore genetic differentiation
###---------------------------------------------

### 1. Iinital import and data filtering

###---------------------------------------------

# CLEAR - Global Environment
# SESSION > SET WORKING DIRECTORY > TO SOURCE FILE LOCATION

rm(list=ls(all=TRUE))

# Load packages
library(adegenet)
library(poppr)
library(FactoMineR)
library(hierfstat)

# Import genotypes - denovo dataset from all samples, with --write-single-snp
# Loci are only processed if they are present in ALL 33 pops!
# to form genind object, .genepop files must be renamed .gen at source
geno = import2genind("populations.snps.gen")
geno
# -R 0.9 dataset of only Atlantic samples (with max het at 0.6 and min maf at 0.005 [2 alleles/400])
# -p 27 (loci must be present in EVERY pop) and single snp per locus
# 200 individuals processed 
# Dataset gives 9812 SNP loci from denovo mapped H. gammarus RADtags
# All alleles are initially polymorphic (i.e. nalleles = nloci x2)

# Assess missing data by locus is not necessary - 90% typed filter used in Stacks

# Assess missing data by individual
indmiss = propTyped(geno, by="ind")
indmiss
indmiss[which(indmiss < 0.8)] 
# 16 individuals missing 20%+ genotypes (80% data) BUT NONE OF OOSTERSCHELDE 7
indmiss[which(indmiss < 0.7)] 
# 9 individuals missing 30%+ genotypes (70% data)
indmiss[which(indmiss < 0.75)] 
# 12 individuals missing 25%+ genotypes (75% data) - 12 lost dataset

geno.filt = missingno(geno, type="geno", cutoff=0.25)

## Found 232588 missing values.
## 12 genotypes contained missing values greater than 25%
## Removing 12 genotypes: Ber20, Arr07, Heb04, Hel29, Iom24, Loo29, Loo34,
## Pad01, Pem28, Tro03, Tro09, Vig32

## 12 individuals removed (only 1 per pop except 2 each from Loo & Tro): 


geno.filt
summary(geno.filt$pop)
nPop(geno.filt)
# full dataset is 188 samples typed at 9812 loci, across 27 pops
# minimum pop size is 4 (Loo/Tro) max size is 11 (Lys)
# the minimum loci typed is Pen40 (0.7790461 = minimum 7,644 SNPs typed) 

# rename the dataset, and then the population sample names 

data_filt <- geno.filt

data_filt
nPop(data_filt)
# shows I=188, L=9812, P=27
summary(data_filt$pop)
# Pop names are individual names at the moment

#Rename pops for figures etc
popNames(data_filt) = gsub("Ber28", "Ber", popNames(data_filt))
popNames(data_filt) = gsub("Brd35", "Brd", popNames(data_filt))
popNames(data_filt) = gsub("Bre16", "Bre", popNames(data_filt))
popNames(data_filt) = gsub("HOO2", "Cor", popNames(data_filt))
popNames(data_filt) = gsub("Cro24", "Cro", popNames(data_filt))
popNames(data_filt) = gsub("MUL4", "Don", popNames(data_filt))
popNames(data_filt) = gsub("Eye22", "Eye", popNames(data_filt))
popNames(data_filt) = gsub("TVE3", "Flo", popNames(data_filt))
popNames(data_filt) = gsub("Heb38", "Heb", popNames(data_filt))
popNames(data_filt) = gsub("Hel36", "Hel", popNames(data_filt))
popNames(data_filt) = gsub("LRO13", "Idr", popNames(data_filt))
popNames(data_filt) = gsub("Iom34", "Iom", popNames(data_filt))
popNames(data_filt) = gsub("Ios35", "Ios", popNames(data_filt))
popNames(data_filt) = gsub("Jer25", "Jer", popNames(data_filt))
popNames(data_filt) = gsub("VEN3", "Kil", popNames(data_filt))
popNames(data_filt) = gsub("Loo34", "Loo", popNames(data_filt))
popNames(data_filt) = gsub("SIN53", "Lys", popNames(data_filt))
popNames(data_filt) = gsub("Oos34", "Oos", popNames(data_filt))
popNames(data_filt) = gsub("Ork36", "Ork", popNames(data_filt))
popNames(data_filt) = gsub("Pad23", "Pad", popNames(data_filt))
popNames(data_filt) = gsub("Pem28", "Pem", popNames(data_filt))
popNames(data_filt) = gsub("Pen40", "Pen", popNames(data_filt))
popNames(data_filt) = gsub("Sbs20", "Sbs", popNames(data_filt))
popNames(data_filt) = gsub("She28", "She", popNames(data_filt))
popNames(data_filt) = gsub("Tan13", "Tan", popNames(data_filt))
popNames(data_filt) = gsub("Tro16", "Tro", popNames(data_filt))
popNames(data_filt) = gsub("Vig32", "Vig", popNames(data_filt))

summary(data_filt$pop)

# 27 pops - (n = 4min 11max 7mean)

#check for duplicates and polymorphisms (after the removal of missing data samples)

## Check for duplicate genotypes
#?mlg
mlg(data_filt)
# all genotypes unique
genoIDs = mlg.id(data_filt) ; genoIDs
for (i in genoIDs){ # for each element in the list genoIDs
  if (length(genoIDs[i]) > 1){ # if the length is greater than two
    print(i) # print individuals that are duplicates
  }
}

# no duplicated genotypes - 188 individuals ALL unique

## Are loci polymorphic? (Oosterschelde still included here...)
?isPoly
isPoly(data_filt)
poly_snps <- isPoly(data_filt) 
summary(poly_snps)
# WOW!!!!
# so 3627 of our 9812 loci ARE NOT polymorphic after removal of missing data individuals...
# perhaps suggests these 'SNPs' were actually indicative of genotyping error in poor samples??

# create a list of these loci which ARE polymorphic...
poly_loci = names(which(isPoly(data_filt) == TRUE))
data_filt
#9812 loci

# filter the dataset to retain only the polymorphic loci
data_filt = data_filt[loc=poly_loci]
data_filt
#6185 loci


## Output filtered genind object (STILL WITH OOSTERSCHELDE IN)
ATLoosfulldata = paste("ATLoos_fullpoly_",nInd(data_filt),"i-",nLoc(data_filt),
                       "s-",nPop(data_filt),"p.RData",sep="")
ATLoosfulldata
save(data_filt, file=ATLoosfulldata)
# saves genind object and shows number of samples / snps / pops

# reload this dataset
load("ATLoos_fullpoly_188i-6185s-27p.RData")

# Perform quick PCA
pcalob = PCA(data_filt)
plot(pcalob)
# Atlantic cline still visible - Oos also outlying
# manually save plot 

# use poppr function to assess private alleles
?private_alleles()
# show the number of private alleles per site across all loci
private_alleles(data_filt) %>% apply(MARGIN = 1, FUN = sum)
# WOW - no pops have private alleles, except Oosterschelde, which has 16!!! 
# 16 is the number of occurrences of a private allele, not the number of loci
private_alleles(data_filt)
# shows loci 2909_49.04, 18037_40.03 & 42788_22.03
# have private occurrences in Oosterschelde 6, 6 & 4 times, respectively. 

# edited private alleles function to show just the number of LOCI (not INDIVIDUALS) which have private alleles...
private_alleles(data_filt, level = "population", report = "table") |> apply(X = _, MARGIN = 1, FUN = function(row) sum(row >= 1))

# explore the genotypes of Oosterschelde individuals at private sites 
# (are 6x 18037_40.03 3x homozygotes, or 6x heterozygotes, or somewhere between, etc)

# try via creation of new genind with only Oos inds and private SNPs?!

oos = popsub(data_filt, sublist = "Oos")
oos
# that's our 7 individuals... now to select only our 3 Private alleles... 
PAs = c("2909_49", "18037_40", "42788_22")
oosPAs = oos[loc=PAs]

summary(oosPAs)
oosPAs$tab

#IND        2909_49.03 2909_49.04 18037_40.01 18037_40.03 42788_22.01 42788_22.03
#Variant                Private                 Private                 Private
#Oos03          1          1           2           0           2           0
#Oos06         NA         NA           0           2           2           0
#Oos08          1          1           2           0           1           1
#Oos21          2          0           1           1           1           1
#Oos24          1          1           1           1           1           1
#Oos29          1          1           1           1           2           0
#Oos34          0          2           1           1           1           1



# use dartR new function to check private allele info...

# First convert genind to genlight object
data_gl <- gi2gl(data_filt)

# then create the private allele report...
private <- gl.report.pa(data_gl)

private
write.csv(private, file="PrivateAlleleReport_dartR.csv")


summary(isPoly(data_filt)) 
# all loci polymorphic, still...!

# show mean allelic richness per site across all loci
allelic.richness(genind2hierfstat(data_filt))$Ar %>%
  apply(MARGIN = 2, FUN = mean) %>% 
  round(digits = 3)

# All much the same ~1.15 but noticeable that two pops fail are same as FST CIs...
summary(data_filt$pop)
# Tro only give NA (as per diveRsity package), despite Loo also having only 4 samples?
# Mean AR = 1.151; Max AR = 1.156 (Donegal); Min AR = 1.142 (Oosterschelde)


########## Alternative genind creation ++++++++++++++++++++++++++++++++

# Oosterschelde vs all other sites 

data_K2_filt <- data_filt

data_K2_filt
nPop(data_K2_filt)
# shows I=188, L=9812, P=27
summary(data_K2_filt$pop)
# Pop names are individual names at the moment

#Rename pops for K2 approach - OOS = Oosterschelde, all others = ATL
popNames(data_K2_filt) = gsub("Ber", "ATL", popNames(data_K2_filt))
popNames(data_K2_filt) = gsub("Brd", "ATL", popNames(data_K2_filt))
popNames(data_K2_filt) = gsub("Bre", "ATL", popNames(data_K2_filt))
popNames(data_K2_filt) = gsub("Cor", "ATL", popNames(data_K2_filt))
popNames(data_K2_filt) = gsub("Cro", "ATL", popNames(data_K2_filt))
popNames(data_K2_filt) = gsub("Don", "ATL", popNames(data_K2_filt))
popNames(data_K2_filt) = gsub("Eye", "ATL", popNames(data_K2_filt))
popNames(data_K2_filt) = gsub("Flo", "ATL", popNames(data_K2_filt))
popNames(data_K2_filt) = gsub("Heb", "ATL", popNames(data_K2_filt))
popNames(data_K2_filt) = gsub("Hel", "ATL", popNames(data_K2_filt))
popNames(data_K2_filt) = gsub("Idr", "ATL", popNames(data_K2_filt))
popNames(data_K2_filt) = gsub("Iom", "ATL", popNames(data_K2_filt))
popNames(data_K2_filt) = gsub("Ios", "ATL", popNames(data_K2_filt))
popNames(data_K2_filt) = gsub("Jer", "ATL", popNames(data_K2_filt))
popNames(data_K2_filt) = gsub("Kil", "ATL", popNames(data_K2_filt))
popNames(data_K2_filt) = gsub("Loo", "ATL", popNames(data_K2_filt))
popNames(data_K2_filt) = gsub("Lys", "ATL", popNames(data_K2_filt))
popNames(data_K2_filt) = gsub("Oos", "OOS", popNames(data_K2_filt))
popNames(data_K2_filt) = gsub("Ork", "ATL", popNames(data_K2_filt))
popNames(data_K2_filt) = gsub("Pad", "ATL", popNames(data_K2_filt))
popNames(data_K2_filt) = gsub("Pem", "ATL", popNames(data_K2_filt))
popNames(data_K2_filt) = gsub("Pen", "ATL", popNames(data_K2_filt))
popNames(data_K2_filt) = gsub("Sbs", "ATL", popNames(data_K2_filt))
popNames(data_K2_filt) = gsub("She", "ATL", popNames(data_K2_filt))
popNames(data_K2_filt) = gsub("Tan", "ATL", popNames(data_K2_filt))
popNames(data_K2_filt) = gsub("Tro", "ATL", popNames(data_K2_filt))
popNames(data_K2_filt) = gsub("Vig", "ATL", popNames(data_K2_filt))

data_K2_filt
nPop(data_K2_filt)
# shows I=188, L=6185, P=2
summary(data_K2_filt$pop)
# ATL=181  OOS=7

## Output filtered genind object 
ATLoosfulldataK2 = paste("ATLoos_fullpoly_",nInd(data_K2_filt),"i-",nLoc(data_K2_filt),
                       "s-",nPop(data_K2_filt),"p.RData",sep="")
ATLoosfulldataK2
save(data_K2_filt, file=ATLoosfulldataK2)
# saves genind object and shows number of samples / snps / pops

# # # # # # # # -------- !  END  ! -------- # # # # # # # #
