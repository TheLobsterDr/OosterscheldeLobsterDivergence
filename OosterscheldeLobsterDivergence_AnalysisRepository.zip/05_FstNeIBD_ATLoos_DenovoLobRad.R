# Basic Pop Gen Analyses 
#
# RAD lobster dataset - C Ellis 2021
#
# Pop pairwise Fst and tests of IBD

# load packages
library(adegenet)
library(poppr)
library(dplyr)
library(hierfstat)
library(reshape2)
library(ggplot2)
library(RColorBrewer)
library(scales)
library(dartR)

# Set Working Directory to Source File and clear Global Environment

# load dataset
load("ATLoos_fullpoly_188i-6185s-27p.RData")

data_filt
summary(data_filt$pop)
nPop(data_filt)

# calculate private alleles per site
private_alleles(data_filt) %>% apply(MARGIN = 1, FUN = sum)
# 16 Oosterschelde private alleles, none elsewhere
# but this is 16 alleles which are private in oosterschelde, across 3 loci, not 16x loci!

neutral.ATLoos
private_alleles(neutral.ATLoos) %>% apply(MARGIN = 1, FUN = sum)
# no private alleles among all 6154 of the neutral snps?!?

outlier.data.overlapATLoos
private_alleles(outlier.data.overlapATLoos) %>% apply(MARGIN = 1, FUN = sum)
# ALL 16 private alleles are from the 31 outliers... 


# Calculate basic stats using hierfstat
basic_lobhet = basic.stats(neutral.ATLoos, diploid = TRUE)
basic_lobhet

# shows that for all loci, summary stats are;
# Ho     Hs     Ht     Dst    Htp    Dstp    Fst    Fstp    Fis    Dest 
# 0.1371 0.1521 0.1531 0.0010 0.1531 0.0011 0.0067 0.0070 0.0982 0.0013


# Mean observed heterozygosity per site
Ho_lobster = apply(basic_lobhet$Ho, MARGIN = 2, FUN = mean, 
                   na.rm = TRUE) %>%  round(digits = 3)
Ho_lobster
# H-obs is relatively low across all 6.5k loci; 
# min 0.11 (Tro), max 0.15 (Don/Brd/Loo)
# Oos is relatively average at 0.13 - no suggestion of much lower observed Heterozygosity

# Mean expected heterozygosity per site
He_lobster = apply(basic_lobhet$Hs, MARGIN = 2, FUN = mean, 
                   na.rm = TRUE) %>%  round(digits = 3)
He_lobster
# Pretty similar to Ho - all expected to be 0.15 - 0.16 (except Oos, 0.14)

# Mean inbreeding coefficient (FIS) per site
Fis_lobster = apply(basic_lobhet$Fis, MARGIN = 2, FUN = mean, 
                   na.rm = TRUE) %>%  round(digits = 3)
Fis_lobster




# Create a data.frame of site names, Ho and He and then convert to long format
Het_lobster_df = data.frame(Site = names(Ho_lobster), Ho = Ho_lobster, 
                            He = He_lobster) %>%  melt(id.vars = "Site")




# Custom theme for ggplot2
custom_theme = theme(
  axis.text.x = element_text(size = 10, angle = 90, vjust = 0.5, face = "bold"),
  axis.text.y = element_text(size = 10),
  axis.title.y = element_text(size = 12),
  axis.title.x = element_blank(),
  axis.line.y = element_line(size = 0.5),
  legend.title = element_blank(),
  legend.text = element_text(size = 12),
  panel.grid = element_blank(),
  panel.background = element_blank(),
  plot.title = element_text(hjust = 0.5, size = 15, face="bold")
)

# Italic label
hetlab.o = expression(italic("H")[o])
hetlab.e = expression(italic("H")[e])

# Lobster heterozygosity barplot
ggplot(data = Het_lobster_df, aes(x = Site, y = value, fill = variable))+
  geom_bar(stat = "identity", position = position_dodge(width = 0.6), colour = "black")+
  scale_y_continuous(expand = c(0,0), limits = c(0,0.20))+
  scale_fill_manual(values = c("royalblue", "#bdbdbd"), labels = c(hetlab.o, hetlab.e))+
  ylab("Heterozygosity")+
  ggtitle("European lobster heterozygosity, all 6185 snps")+
  custom_theme


# Now what about heterozygosity specifically at outliers??

# Calculate basic stats using hierfstat
outlier_lobhet = basic.stats(outlier.data.overlapATLoos, diploid = TRUE)

# Mean observed heterozygosity per site
Ho_lob.outlier = apply(outlier_lobhet$Ho, MARGIN = 2, FUN = mean, 
                   na.rm = TRUE) %>%  round(digits = 2)
Ho_lob.outlier
# more varied... low in Scandi (min Tro=0.05), high in W UK (max Loo=0.33), average in Oos (o.22)

# Mean expected heterozygosity per site
He_lob.outlier = apply(outlier_lobhet$Hs, MARGIN = 2, FUN = mean, 
                   na.rm = TRUE) %>%  round(digits = 2)
He_lob.outlier
# Pretty similar to Ho

# Create a data.frame of site names, Ho and He and then convert to long format
Het_lobster_df.outlier = data.frame(Site = names(Ho_lob.outlier), Ho = Ho_lob.outlier, 
                            He = He_lob.outlier) %>%  melt(id.vars = "Site")
Het_lobster_df.outlier

# Italic label
hetlab.o = expression(italic("H")[o])
hetlab.e = expression(italic("H")[e])

# Lobster heterozygosity barplot
ggplot(data = Het_lobster_df.outlier, aes(x = Site, y = value, fill = variable))+
  geom_bar(stat = "identity", position = position_dodge(width = 0.6), colour = "black")+
  scale_y_continuous(expand = c(0,0), limits = c(0,0.4))+
  scale_fill_manual(values = c("red", "#bdbdbd"), labels = c(hetlab.o, hetlab.e))+
  ylab("Heterozygosity")+
  ggtitle("European lobster heterozygosity, 31 outlier snps")+
  custom_theme

# manual save if needed



##### =========================================================== #####
##### ========================== FSTATS ========================= #####
##### =========================================================== #####

# use the package heirfstat to calculate Fst, globally and pairwise

# European lobster Fis - calculate inbreeding coefficient
apply(basic_lobhet$Fis, MARGIN = 2, FUN = mean, na.rm = TRUE) %>%
  round(digits = 3)
# this is more variable... copy and save to Allelic Richness spreadsheet


# FST

library(hierfstat)

# use hierfstat to compute global Fst across all pops & loci
?fstat
fstats_lob = fstat(data_filt, pop=data_filt$pop, fstonly = FALSE)
fstats_lob

#      pop         Ind
#Total 0.008286423 0.1015611
#pop   0.000000000 0.0940541

#Fst=0.008
#Fit=0.102
#Fis=0.094


# Thats global... now how about within specific pops and regions
# Probably an easier way of doing this, but for now just create individual geninds
data_filt
summary(data_filt$pop)


# FST of neutral only loci
load("NeutralData_188i6154s27p.RData")
neutral.ATLoos

# use hierfstat to compute global Fst across all pops at only 6154 neutral loci
?fstat

fstats_neut = fstat(neutral.ATLoos, pop=neutral.ATLoos$pop, fstonly = FALSE)
fstats_neut

?basic.stats

basic_neut = basic.stats(neutral.ATLoos, diploid = TRUE, digits = 5)
basic_neut

#overall
#Ho      Hs      Ht      Dst     Htp     Dstp    Fst     Fstp    Fis     Dest 
#0.13714 0.15208 0.15310 0.00103 0.15314 0.00106 0.00670 0.00695 0.09818 0.00126 

# So global neutral Fst = 0.0067 / 0.0070 depending on Nei's measure 



# now outliers only...
load("OutlierData_31snpsOFKorBAY_188i31s27p.RData")

basic_out = basic.stats(outlier.data.overlapATLoos, diploid = TRUE, digits = 5)
basic_out

#overall
#Ho      Hs      Ht      Dst     Htp     Dstp    Fst     Fstp    Fis     Dest 
#0.17572 0.18449 0.24033 0.05584 0.24248 0.05799 0.23236 0.23916 0.04754 0.07111 

# So global outlier Fst = 0.2324 / 0.2392 depending on Nei's measure 




# to compare Nei's to W&Cs Fst values from previous (now defunct) hierfstat::fstats() function, run global all loci... 

basic_all = basic.stats(data_filt, diploid = TRUE, digits = 5)
basic_all

#overall
#Ho      Hs      Ht      Dst     Htp     Dstp    Fst     Fstp    Fis     Dest 
#0.13734 0.15224 0.15354 0.00130 0.15359 0.00135 0.00847 0.00879 0.09788 0.00159 

# So global Fst across all 6185 loci = 0.00847 / 0.00879 depending on Nei's measure (was 0.00828 via W&Cs84)



# create Oosterschelde-vs-AllATL genind to investigate this in  

### ==========================================================
### Create alternative genind to investigate Fst between DAPC clusters
### ----------------------------------------------------------

data_ATLvOos <- data_filt
data_ATLvOos
summary(data_ATLvOos$pop)
# as is for now - pool all pops other than Oos into one Atl pop to investigate differentiation between them 

popNames(data_ATLvOos) = gsub("Ber", "Atl", popNames(data_ATLvOos))
popNames(data_ATLvOos) = gsub("Brd", "Atl", popNames(data_ATLvOos))
popNames(data_ATLvOos) = gsub("Bre", "Atl", popNames(data_ATLvOos))
popNames(data_ATLvOos) = gsub("Cor", "Atl", popNames(data_ATLvOos))
popNames(data_ATLvOos) = gsub("Cro", "Atl", popNames(data_ATLvOos))
popNames(data_ATLvOos) = gsub("Don", "Atl", popNames(data_ATLvOos))
popNames(data_ATLvOos) = gsub("Eye", "Atl", popNames(data_ATLvOos))
popNames(data_ATLvOos) = gsub("Flo", "Atl", popNames(data_ATLvOos))
popNames(data_ATLvOos) = gsub("Heb", "Atl", popNames(data_ATLvOos))
popNames(data_ATLvOos) = gsub("Hel", "Atl", popNames(data_ATLvOos))
popNames(data_ATLvOos) = gsub("Idr", "Atl", popNames(data_ATLvOos))
popNames(data_ATLvOos) = gsub("Iom", "Atl", popNames(data_ATLvOos))
popNames(data_ATLvOos) = gsub("Ios", "Atl", popNames(data_ATLvOos))
popNames(data_ATLvOos) = gsub("Jer", "Atl", popNames(data_ATLvOos))
popNames(data_ATLvOos) = gsub("Kil", "Atl", popNames(data_ATLvOos))
popNames(data_ATLvOos) = gsub("Loo", "Atl", popNames(data_ATLvOos))
popNames(data_ATLvOos) = gsub("Lys", "Atl", popNames(data_ATLvOos))
popNames(data_ATLvOos) = gsub("Ork", "Atl", popNames(data_ATLvOos))
popNames(data_ATLvOos) = gsub("Pad", "Atl", popNames(data_ATLvOos))
popNames(data_ATLvOos) = gsub("Pem", "Atl", popNames(data_ATLvOos))
popNames(data_ATLvOos) = gsub("Pen", "Atl", popNames(data_ATLvOos))
popNames(data_ATLvOos) = gsub("Sbs", "Atl", popNames(data_ATLvOos))
popNames(data_ATLvOos) = gsub("She", "Atl", popNames(data_ATLvOos))
popNames(data_ATLvOos) = gsub("Tan", "Atl", popNames(data_ATLvOos))
popNames(data_ATLvOos) = gsub("Tro", "Atl", popNames(data_ATLvOos))
popNames(data_ATLvOos) = gsub("Vig", "Atl", popNames(data_ATLvOos))

summary(data_ATLvOos$pop)
data_ATLvOos

# Compute pairwise Fst using new hierfstat method - genet.dist
?genet.dist
ATLoos_Fst <- genet.dist(data_ATLvOos, method = "WC84")
# D <- pairwise_D(data_ATLvOos)
ATLoos_Fst
#FST         Atl
#     Oos 0.03508122



# Compare to data_filt with 27 samples as per location; compute pairwise Fst using new hierfstat method - genet.dist
data_filt
summary(data_filt$pop)

full_Fst <- genet.dist(data_filt, method = "WC84")
# D <- pairwise_D(data_filt)
full_Fst













# use diveRsity instead...
library(diveRsity)

# first step is to convert genind to genepop using graph4lg package
library(graph4lg)


OosVsATL_data_gp <- genind_to_genepop(data_ATLvOos, output = "data.frame")
#ATLoos_data_gp
OosVsATL_data_gp[1:50, c(1:9)] 

# Run diffCalc function of diveRsity
# Use 100 bootstraps - 1000 crashes laptop; run with 100 still takes saveralhrs!!!!!
# outfile creates a new folder full of files in the session directory - TAKES UP TO 24hrs TO RUN!!!
OosVsATL_diffcalc <- diffCalc(infile=OosVsATL_data_gp, outfile="diffCalc Oos-vs-ATL",
                            fst = TRUE, pairwise = FALSE, bs_locus = TRUE,
                            bs_pairwise = FALSE, ci_type = "loci",
                            boots = 100, para = TRUE)

#stat	actual	lower	  upper
#gst	0.0167	0.0153	0.0180
#Gst	0.0197	0.0182	0.0213
#GGst	0.0204	0.0187	0.0219
#D  	0.0003	0.0002	0.0003
#Fst	0.0083	0.0070	0.0094
#Fit	0.1016	0.0990	0.1049
#Fis	0.0941	0.0913	0.0975





# now with pairwise values (to try and get sitewise Tajima's D - a useful metric to measure genetic diversity loss) 

OosVsATL_data_gp <- genind_to_genepop(data_filt, output = "data.frame")
#ATLoos_data_gp
OosVsATL_data_gp[1:50, c(1:9)] 

# Run diffCalc function of diveRsity
# Use 100 bootstraps - 1000 crashes laptop; run with 100 still takes several hrs!!!!!
# outfile creates a new folder full of files in the session directory - TAKES UP TO 24hrs TO RUN!!!
OosVsATL_diffcalc <- diffCalc(infile=OosVsATL_data_gp, outfile="diffCalc OosATL_pw",
                              fst = TRUE, pairwise = TRUE, bs_locus = TRUE,
                              bs_pairwise = FALSE, ci_type = "loci",
                              boots = 100, para = TRUE)

#stat	actual	lower	  upper
#gst	0.0167	0.0153	0.0180
#Gst	0.0197	0.0182	0.0213
#GGst	0.0204	0.0187	0.0219
#D  	0.0003	0.0002	0.0003
#Fst	0.0083	0.0070	0.0094
#Fit	0.1016	0.0990	0.1049
#Fis	0.0941	0.0913	0.0975












#create alternative geninds for adjacent unstructured regional groups

#create Scandi only RADseq genind, using sublist ('keep these pops'), not blacklist ('lose these pops')
# don't use Trondheim pop - only 4 individuals and quite distant
# don't use Helgoland - we'll keep that and Shoreham as our two small neighbour controls
fulldata_scandi = popsub(data_filt, sublist = c("Lys", "Flo", "Ber"))
fulldata_scandi

fstats_scandi = fstat(fulldata_scandi, pop=NULL, fstonly = FALSE)
fstats_scandi

#         pop       Ind
#Total 0.001159073 0.1178721
#pop   0.000000000 0.1168485

#create UK NORTH SEA only RADseq genind
fulldata_wNsea = popsub(data_filt, sublist = c("Brd", "Eye", "Ork"))
fulldata_wNsea

fstats_wNsea = fstat(fulldata_wNsea, pop=NULL, fstonly = FALSE)
fstats_wNsea

#       pop        Ind
#Total 0.001514181 0.09154384
#pop   0.000000000 0.09016618


#create W Channel only RADseq genind
fulldata_channel = popsub(data_filt, sublist = c("Jer", "Loo", "Ios", "Bre"))
fulldata_channel

fstats_channel = fstat(fulldata_channel, pop=NULL, fstonly = FALSE)
fstats_channel

#             pop        Ind
#Total -0.0008987165 0.07313874
#pop    0.0000000000 0.07397098


# Try and decide Oosterschelde FIT etc by including and removing from equal sized pop pairs?
summary(data_filt$pop)
# IoS and Pen fit the brief... although not sure this method is valid?!?

fulldata_oosios = popsub(data_filt, sublist = c("Oos", "Ios"))
fulldata_oosios

fstats_oosios = fstat(fulldata_oosios, pop=fulldata_oosios$pop, fstonly = FALSE)
fstats_oosios

#           pop        Ind
#Total 0.04413388 0.13578720
#pop   0.00000000 0.09588509

fulldata_oospen = popsub(data_filt, sublist = c("Oos", "Pen"))
fulldata_oospen

fstats_oospen = fstat(fulldata_oospen, pop=fulldata_oospen$pop, fstonly = FALSE)
fstats_oospen

#             pop       Ind
#Total 0.04763075 0.1546600
#pop   0.00000000 0.1123821

fulldata_iospen = popsub(data_filt, sublist = c("Ios", "Pen"))
fulldata_iospen

fstats_iospen = fstat(fulldata_iospen, pop=fulldata_iospen$pop, fstonly = FALSE)
fstats_iospen

#              pop        Ind
#Total 0.003949085 0.09150441
#pop   0.000000000 0.08790246

# NOPE! can't see that that's a valid way of calculating popwise FIT / FIS! :( 


# now run global estimates of Fst 95% CIs, using diveRsity package. 
# !!!WARNING!!! Use 100 bootstraps MAX as higher values tend to crash laptop!!!
########## +++++++++ !!!! EACH RUN TAKES 24HRS TO PROCESS !!!! +++++++++ ######
data_filt

# first step is to convert genind to genepop using graph4lg package
#install.packages("graph4lg")
library(graph4lg)

ATLoos_data_gp <- genind_to_genepop(data_filt, output = "data.frame")
#ATLoos_data_gp
ATLoos_data_gp[1:9, c(1:9)] 
# save this genopop object for use in snpR Ne calculation function later...

# try saving as .csv
write.csv(ATLoos_data_gp, file="ATLoos_188i6185s27p_genepopfile.csv")
# edit file in text editor to remove extra rows, columns and characters


# install Diversity via R4.3 must be done via github not CRAN

devtools::install_github("kkeenan02/diveRsity")

library(diveRsity)

ATLoos_diffcalc <- diffCalc(infile=ATLoos_data_gp, outfile="diffCalc ATLoos100bs",
                           fst = TRUE, pairwise = FALSE, bs_locus = TRUE,
                           bs_pairwise = FALSE, ci_type = "loci",
                           boots = 100, para = TRUE)

# 1000 bootstraps crashes laptop, run with 100!!!
# outfile creates a new folder full of files in the session directory.

#F    measure upper   lower
#Fst	0.0083	0.0072	0.0094
#Fit	0.1016	0.0986	0.1048
#Fis	0.0941	0.0908	0.0979


### ==========================================================
### Create alternative genind to investigate Fst between DAPC clusters
### ----------------------------------------------------------

data_clustered <- data_filt
data_clustered
summary(data_clustered$pop)

popNames(data_clustered) = gsub("Ber", "Sca", popNames(data_clustered))
popNames(data_clustered) = gsub("Brd", "Atl", popNames(data_clustered))
popNames(data_clustered) = gsub("Bre", "Atl", popNames(data_clustered))
popNames(data_clustered) = gsub("Cor", "Atl", popNames(data_clustered))
popNames(data_clustered) = gsub("Cro", "Atl", popNames(data_clustered))
popNames(data_clustered) = gsub("Don", "Atl", popNames(data_clustered))
popNames(data_clustered) = gsub("Eye", "Atl", popNames(data_clustered))
popNames(data_clustered) = gsub("Flo", "Sca", popNames(data_clustered))
popNames(data_clustered) = gsub("Heb", "Atl", popNames(data_clustered))
popNames(data_clustered) = gsub("Hel", "Sca", popNames(data_clustered))
popNames(data_clustered) = gsub("Idr", "Atl", popNames(data_clustered))
popNames(data_clustered) = gsub("Iom", "Atl", popNames(data_clustered))
popNames(data_clustered) = gsub("Ios", "Atl", popNames(data_clustered))
popNames(data_clustered) = gsub("Jer", "Atl", popNames(data_clustered))
popNames(data_clustered) = gsub("Kil", "Atl", popNames(data_clustered))
popNames(data_clustered) = gsub("Loo", "Atl", popNames(data_clustered))
popNames(data_clustered) = gsub("Lys", "Sca", popNames(data_clustered))
popNames(data_clustered) = gsub("Ork", "Atl", popNames(data_clustered))
popNames(data_clustered) = gsub("Pad", "Atl", popNames(data_clustered))
popNames(data_clustered) = gsub("Pem", "Atl", popNames(data_clustered))
popNames(data_clustered) = gsub("Pen", "Ibe", popNames(data_clustered))
popNames(data_clustered) = gsub("Sbs", "Atl", popNames(data_clustered))
popNames(data_clustered) = gsub("She", "Atl", popNames(data_clustered))
popNames(data_clustered) = gsub("Tan", "Ibe", popNames(data_clustered))
popNames(data_clustered) = gsub("Tro", "Sca", popNames(data_clustered))
popNames(data_clustered) = gsub("Vig", "Ibe", popNames(data_clustered))

summary(data_clustered$pop)

Fst_clustersK4 = fstat(data_clustered, pop=data_clustered$pop, fstonly = FALSE)
Fst_clustersK4

# and now estimate associate Fst 95% CIs

K4data_gen <- genind_to_genepop(data_clustered, output = "data.frame")
#K4data_gen
K4data_gen[1:9, c(1:9)] 

#?diffCalc

# now run estimates of Fst 95% CIs. 
# !!!WARNING!!! Use 100 bootstraps MAX as higher values tend to crash laptop!!!
K4_diffcalc <- diffCalc(infile=K4data_gen, outfile="diffCalc K4clusters100bs",
                          fst = TRUE, pairwise = FALSE, bs_locus = TRUE,
                          bs_pairwise = FALSE, ci_type = "loci",
                          boots = 100, para = TRUE)

# check the corresponding diffcalc folders auto created in the session folder

#F    Global  Upper   Lower
#Fst	0.0126	0.0112	0.0140
#Fit	0.1069	0.1037	0.1106
#Fis	0.0956	0.0921	0.0990

# this is (expectedly) quite a bit higher than the dataset as per 27 pops

#### And repeat separately for both neutral and outlier subsets ####


# First, neutral only dataset Fst estimate
load("NeutralData_188i6154s27p.RData")
neutral.ATLoos
Fst_neutral = fstat(neutral.ATLoos, pop=neutral.ATLoos$pop, fstonly = FALSE)
Fst_neutral

# Fst = 0.01163 globally across only neutral loci (outliers removed)

#             pop        Ind
#Total 0.01163465 0.09981565
#pop   0.00000000 0.08921903

# and now estimate associate Fst 95% CIs

neutraldata_gen <- genind_to_genepop(neutral.ATLoos, output = "data.frame")
#neutraldata_gen
neutraldata_gen[1:9, c(1:9)] 

#?diffCalc

# now run estimates of Fst 95% CIs. 
# !!!WARNING!!! Use 100 bootstraps MAX as higher values tend to crash laptop!!!
NEUTRALdiffcalc <- diffCalc(infile=neutraldata_gen, outfile="diffCalc neutral100bs",
                            fst = TRUE, pairwise = FALSE, bs_locus = TRUE,
                            bs_pairwise = FALSE, ci_type = "loci",
                            boots = 100, para = TRUE)

# check the corresponding diffcalc folders auto created in the session folder

#F    Global  Upper   Lower
#Fst	0.0065	0.0055	0.0076
#Fit	0.1002	0.0974	0.1033
#Fis	0.0943	0.0917	0.0972



#############################################################

# And now the 31 Bayescan or Outflank outliers...

# Lastly, outlier only dataset Fst estimate
load("OutlierData_31snpsOFKorBAY_188i31s27p.RData")
outlier_data

Fst_outlier = fstat(outlier_data, pop=outlier_data$pop, fstonly = FALSE)
Fst_outlier

# Fst = 0.2388726 globally across only the 31 outlier loci 

#      pop       Ind
#Total 0.2388726 0.28033475
#pop   0.0000000 0.05447468

# and now estimate associate Fst 95% CIs

outlierdata_gen <- genind_to_genepop(outlier_data, output = "data.frame")
#outlierdata_gen
outlierdata_gen[1:9, c(1:9)] 

#?diffCalc

# now run estimates of Fst 95% CIs. 
# !!!WARNING!!! Use 100 bootstraps MAX as higher values tend to crash laptop!!!
OUTLIERdiffcalc <- diffCalc(infile=outlierdata_gen, outfile="diffCalc outlier100bs",
                            fst = TRUE, pairwise = FALSE, bs_locus = TRUE,
                            bs_pairwise = FALSE, ci_type = "loci",
                            boots = 100, para = TRUE)

#     Fstat   UpperCI LowerCI
#Fst	0.2389	0.2075	0.2696
#Fit	0.2803	0.2543	0.3170
#Fis	0.0545	0.0187	0.0866


# check the corresponding diffcalc folders auto created in the session folder




##################################################################
#                                                                #
#                         FST PLOTTING                           #
#                                                                #  
##################################################################


# PW Fst calculation and heatmap plotting. First up - pops as sampled (K=27) and all loci (neut & outliers)

# Compute pairwise Fsts (Weir & Cockerham, 1984)
lobster_fst = genet.dist(data_filt, method = "WC84")
# increase max print length and then print this matrix
options(max.print=100000)
lobster_fst %>% round(digits = 3)
# copy to excel to save as pairwise table for mantel tests etc

# Convert dist object to data.frame
fst.matrix = as.matrix(lobster_fst)
ind = which( upper.tri(fst.matrix), arr.ind = TRUE)
fst.df = data.frame(Site1 = dimnames(fst.matrix)[[2]][ind[,2]],
                    Site2 = dimnames(fst.matrix)[[1]][ind[,1]],
                    Fst = fst.matrix[ ind ] %>% round(digits = 3))

# Convert minus values to zero
fst.df$Fst[fst.df$Fst < 0] = 0.000

# Print data.frame summary
fst.df %>% str

# save to .csv
write.csv(fst.df, file="Fst-list_popPW-WC84.csv")

fst.df = read.csv("Fst-list_popPW-WC84.csv", row.names = 1)
fst.df

# Fst italic label
fst.label = expression(italic("F")[ST])

# Extract middle Fst value for gradient argument
mid = max(fst.df$Fst) / 2

# Plot heatmap
ggplot(data = fst.df, aes(x = Site1, y = Site2, fill = Fst))+
  geom_tile(colour = "black")+
  geom_text(aes(label = Fst), color="black", size = 3)+
  scale_fill_gradient(low = "deepskyblue", 
                      #mid = "pink", 
                      high = "red", 
                      #midpoint = mid, 
                      name = fst.label, 
                      limits = c(0, 0.065), 
                      breaks = c(0, 0.015, 0.030, 0.045, 0.060))+
  scale_x_discrete(expand = c(0,0))+
  scale_y_discrete(expand = c(0,0), position = "right")+
  theme(axis.text = element_text(colour = "black", size = 10, face = "bold"),
        axis.title = element_blank(),
        panel.grid = element_blank(),
        panel.background = element_blank(),
        legend.position = "right",
        legend.title = element_text(size = 14, face = "bold"),
        legend.text = element_text(size = 10)
  )

## Export plot
titleFstheatmap = paste("Fst_PWheatmap-ATLoos_",nInd(data_filt),"i",
                      nLoc(data_filt),"s",nPop(data_filt),"p", sep="")
titleFstheatmap
ggsave(paste(titleFstheatmap,".png",sep=""), width=12, height=12, dpi=300)
ggsave(paste(titleFstheatmap,".pdf",sep=""), width=12, height=12)



# Redo with pops ordered geographically/latitudinally rather than alphabetically
# and with x axis pop labels running vertically

# upload this matrix (cut to shape and saved as .csv)
fst.df.loboos = read.csv("Fst-matrix_FullPWzeroed_188i6185s27p.csv", row.names = 1)
fst.df.loboos

fst.matrix.loboos = as.matrix(fst.df.loboos)
fst.matrix.loboos

#make vectors with new population names in geographic order
col.order.loboos = c("Lys", "Flo", "Tro", "Ber", "Hel", "Oos", 
                     "Cro", "Brd", "Eye",
                     "She", "Ork", "Heb", "Iom", "Don", "Kil", "Cor", "Pem",
                     "Pad", "Ios", "Loo", "Sbs", "Jer", "Bre", "Idr", "Vig",
                     "Pen", "Tan")


row.order.loboos = c("Lys", "Flo", "Tro", "Ber", "Hel", "Oos", 
                     "Cro", "Brd", "Eye",
                     "She", "Ork", "Heb", "Iom", "Don", "Kil", "Cor", "Pem",
                     "Pad", "Ios", "Loo", "Sbs", "Jer", "Bre", "Idr", "Vig",
                     "Pen", "Tan")

fstr.loboos = fst.matrix.loboos[row.order.loboos,]
fstc.loboos = fstr.loboos[,col.order.loboos]

#Create a dataframe
ind = which(upper.tri(fstc.loboos), arr.ind = TRUE)
fst.df.loboos = data.frame(Site1 = dimnames(fstc.loboos)[[2]][ind[,2]],
                           Site2 = dimnames(fstc.loboos)[[1]][ind[,1]],
                           FST = fstc.loboos[ ind ] %>% round(digits = 3))

#Convert minus values to zero
fst.df.loboos$FST[fst.df.loboos$FST < 0] = 0

#Print the dataframe
fst.df.loboos %>% str()

# create Fst label
fst.label = expression(italic("F")[ST])

#Extract middle Fst value for gradient argument 
mid = max(fst.df.loboos$FST) / 2
mid
#0.031

#Tell R to keep the order of the levels in the dataframe for plotting 
fst.df.loboos$Site1 = factor(fst.df.loboos$Site1, levels = unique(fst.df.loboos$Site1))
fst.df.loboos$Site2 = factor(fst.df.loboos$Site2, levels = unique(fst.df.loboos$Site2))

# Plot heatmap - with pops geographically ordered and FST values labelled
# (colours adjusted from blue-pink-red to approx match clawed lobster scale)
ggplot(data = fst.df.loboos, aes(x = Site1, y = Site2, fill = FST))+
  geom_tile(colour = "black")+
  geom_text(aes(label = FST), color="black", size = 3)+
  scale_fill_gradient(low = "deepskyblue", high = "red", name = fst.label, 
                       limits = c(0, 0.062), breaks = c(0, 0.015, 0.030, 0.045, 0.060))+
  scale_x_discrete(expand = c(0,0))+
  scale_y_discrete(expand = c(0,0), position = "right")+
  theme(axis.text.y = element_text(colour = "black", size = 10, face = "bold"),
        axis.text.x = element_text(colour = "black", size = 10, face = "bold", 
                                   angle=90, vjust=0.5),
        axis.title = element_blank(),
        panel.grid = element_blank(),
        panel.background = element_blank(),
        legend.position = "right",
        legend.title = element_text(size = 14, face = "bold"),
        legend.text = element_text(size = 10)
  )

## Export plot
ggsave("Fst_PWheatmap_WithOosterschelde.png", width=12, height=12, dpi=300)


#
# Plot heatmap - with pops geographically ordered but no FST value labels
# (colours adjusted from blue-pink-red to approx match clawed lobster scale)
ggplot(data = fst.df.loboos, aes(x = Site1, y = Site2, fill = FST))+
  geom_tile(colour = "black")+
#  geom_text(aes(label = FST), color="black", size = 3)+
  scale_fill_gradient(low = "deepskyblue", high = "red", name = fst.label, 
                      limits = c(0, 0.062), breaks = c(0, 0.015, 0.030, 0.045, 0.060))+
  scale_x_discrete(expand = c(0,0))+
  scale_y_discrete(expand = c(0,0), position = "right")+
  theme(axis.text.y = element_text(colour = "black", size = 16), #face = "bold"),
        axis.text.x = element_text(colour = "black", size = 16, #face = "bold", 
                                   angle=90, vjust=0.5),axis.title = element_blank(),
        panel.grid = element_blank(),
        panel.background = element_blank(),
        legend.position = "right",
        legend.title = element_text(size = 14, face = "bold"),
        legend.text = element_text(size = 10)
  )

## Export plot
ggsave("Fst_PWheatmap_GeoOrderNoLabels_vPubFig.png", width=11, height=10, dpi=300)


#
#===================================================================#


# Next... 
# PW Fst calculation and heatmap plotting, but with only neutral loci, and with locally merged pops (K=13)

# FST of neutral only loci
load("NeutralData_188i6154s27p.RData")
neutral.ATLoos
neutral.merged <- neutral.ATLoos

popNames(neutral.merged) = gsub("Ber", "Norw", popNames(neutral.merged))
popNames(neutral.merged) = gsub("Brd", "EaGB", popNames(neutral.merged))
popNames(neutral.merged) = gsub("Bre", "Fran", popNames(neutral.merged))
popNames(neutral.merged) = gsub("Cor", "Eire", popNames(neutral.merged))
popNames(neutral.merged) = gsub("Cro", "EaGB", popNames(neutral.merged))
popNames(neutral.merged) = gsub("Don", "Eire", popNames(neutral.merged))
popNames(neutral.merged) = gsub("Eye", "EaGB", popNames(neutral.merged))
popNames(neutral.merged) = gsub("Flo", "Skag", popNames(neutral.merged))
popNames(neutral.merged) = gsub("Heb", "Scot", popNames(neutral.merged))
popNames(neutral.merged) = gsub("Hel", "Hel", popNames(neutral.merged))
popNames(neutral.merged) = gsub("Idr", "Fran", popNames(neutral.merged))
popNames(neutral.merged) = gsub("Iom", "IriS", popNames(neutral.merged))
popNames(neutral.merged) = gsub("Ios", "Corn", popNames(neutral.merged))
popNames(neutral.merged) = gsub("Jer", "Chan", popNames(neutral.merged))
popNames(neutral.merged) = gsub("Kil", "Eire", popNames(neutral.merged))
popNames(neutral.merged) = gsub("Loo", "Corn", popNames(neutral.merged))
popNames(neutral.merged) = gsub("Lys", "Skag", popNames(neutral.merged))
popNames(neutral.merged) = gsub("Ork", "Scot", popNames(neutral.merged))
popNames(neutral.merged) = gsub("Oos", "Oos", popNames(neutral.merged))
popNames(neutral.merged) = gsub("Pad", "Corn", popNames(neutral.merged))
popNames(neutral.merged) = gsub("Pem", "IriS", popNames(neutral.merged))
popNames(neutral.merged) = gsub("Pen", "Iber", popNames(neutral.merged))
popNames(neutral.merged) = gsub("Sbs", "Chan", popNames(neutral.merged))
popNames(neutral.merged) = gsub("She", "Scot", popNames(neutral.merged))
popNames(neutral.merged) = gsub("Tan", "Tan", popNames(neutral.merged))
popNames(neutral.merged) = gsub("Tro", "Norw", popNames(neutral.merged))
popNames(neutral.merged) = gsub("Vig", "Iber", popNames(neutral.merged))

summary(neutral.merged$pop)

# 13 pops
#Norw EaGB Fran Eire Skag Scot  Hel IriS Corn Chan  Oos Iber  Tan 
#10   21   13   26   19   19    6   12   19   16    7   13    7 

# Only Helgoland and Tangiers not merged - both too distant for this? 
# (check PW dist-matrix for write-up support!)
# Yes - they are the two most distant pops. 
# A cutoff of 500km excludes them merging anything else (Oos <-> Hel = 430km but can't merge Oos!).

save(neutral.merged, file = "ATL-OOS_NeutralMerged_188i6154s13p.RData")

load("ATL-OOS_NeutralMerged_188i6154s13p.RData")

# Compute pairwise Fsts (Weir & Cockerham, 1984) [LONG RUNTIME!!!]
neut.merged_fst = genet.dist(neutral.merged, method = "WC84")
# increase max print length and then print this matrix
#options(max.print=100000)
neut.merged_fst %>% round(digits = 3)
# copy to excel to save as pairwise table for mantel tests etc

# Convert dist object to data.frame
neut.merged_fst.matrix = as.matrix(neut.merged_fst)
ind = which( upper.tri(neut.merged_fst.matrix), arr.ind = TRUE)
neut.merged_fst.df = data.frame(Site1 = dimnames(neut.merged_fst.matrix)[[2]][ind[,2]],
                    Site2 = dimnames(neut.merged_fst.matrix)[[1]][ind[,1]],
                    Fst = neut.merged_fst.matrix[ ind ] %>% round(digits = 3))

# Convert minus values to zero
neut.merged_fst.df$Fst[neut.merged_fst.df$Fst < 0] = 0.000

# Print data.frame summary
neut.merged_fst.df %>% str

# save to .csv
write.csv(neut.merged_fst.df, file="Fst-list_NeutralMerged_popPW-WC84.csv")

neut.merged_fst.df = read.csv("Fst-list_NeutralMerged_popPW-WC84.csv", row.names = 1)
neut.merged_fst.df

# Fst italic label
fst.label = expression(italic("F")[ST])

# Extract middle Fst value for gradient argument
mid = max(neut.merged_fst.df$Fst) / 2
mid
# mid = 0.025, so 

# Plot heatmap
ggplot(data = neut.merged_fst.df, aes(x = Site1, y = Site2, fill = Fst))+
  geom_tile(colour = "black")+
  geom_text(aes(label = Fst), color="black", size = 3)+
  scale_fill_gradient(low = "deepskyblue", 
                      #mid = "pink", 
                      high = "red", 
                      #midpoint = mid, 
                      name = fst.label, 
                      limits = c(0, 0.065), 
                      breaks = c(0, 0.015, 0.030, 0.045, 0.060))+
  scale_x_discrete(expand = c(0,0))+
  scale_y_discrete(expand = c(0,0), position = "right")+
  theme(axis.text = element_text(colour = "black", size = 10, face = "bold"),
        axis.title = element_blank(),
        panel.grid = element_blank(),
        panel.background = element_blank(),
        legend.position = "right",
        legend.title = element_text(size = 14, face = "bold"),
        legend.text = element_text(size = 10)
  )

## Export plot
title_neutralFstheatmap = paste("Fst_PWheatmap_NeutralMerged-ATLoos_",nInd(neutral.merged),"i",
                        nLoc(neutral.merged),"s",nPop(neutral.merged),"p", sep="")
title_neutralFstheatmap
#ggsave(paste(title_neutralFstheatmap,".png",sep=""), width=12, height=12, dpi=300)
#ggsave(paste(title_neutralFstheatmap,".pdf",sep=""), width=12, height=12)



# Redo with pops ordered geographically/latitudinally rather than alphabetically
# and with x axis pop labels running vertically

# upload this matrix (cut to shape and saved as .csv)
neut.merged_fst.df.loboos = read.csv("Fst-matrix_FullPWzeroed_NeutralMerged_188i6154s13p.csv", row.names = 1)
neut.merged_fst.df.loboos

neut.merged_fst.matrix.loboos = as.matrix(neut.merged_fst.df.loboos)
neut.merged_fst.matrix.loboos

# #Norw EaGB Fran Eire Skag Scot Helg IriS Corn Chan Oost Iber Moro 

#make vectors with new population names in geographic order
neut.merged_col.order.loboos = c("NORW", "SKAG", "Hel", "Oos", "EAGB", "SCOT", 
                     "EIRE", "IRIS", "CORN", "CHAN", "FRAN", "IBER", "Tan")


neut.merged_row.order.loboos = c("NORW", "SKAG", "Hel", "Oos", "EAGB", "SCOT", 
                                 "EIRE", "IRIS", "CORN", "CHAN", "FRAN", "IBER", "Tan")

neut.merged_fstr.loboos = neut.merged_fst.matrix.loboos[neut.merged_row.order.loboos,]
neut.merged_fstc.loboos = neut.merged_fstr.loboos[,neut.merged_col.order.loboos]

#Create a dataframe
ind = which(upper.tri(neut.merged_fstc.loboos), arr.ind = TRUE)
neut.merged_fst.df.loboos = data.frame(Site1 = dimnames(neut.merged_fstc.loboos)[[2]][ind[,2]],
                           Site2 = dimnames(neut.merged_fstc.loboos)[[1]][ind[,1]],
                           FST = neut.merged_fstc.loboos[ ind ] %>% round(digits = 3))

#Convert minus values to zero
neut.merged_fst.df.loboos$FST[neut.merged_fst.df.loboos$FST < 0] = 0
# two minus values converted (Scot vs EaGB & Scot vs Fran; both -0.001)  
neut.merged_fst.df.loboos

#Print the dataframe
neut.merged_fst.df.loboos %>% str()

# create Fst label
fst.label = expression(italic("F")[ST])

#Extract middle Fst value for gradient argument 
mid = max(neut.merged_fst.df.loboos$FST) / 2
mid
#0.025
# so max = 0.05, and can be scaled to this :) 

#Tell R to keep the order of the levels in the dataframe for plotting 
neut.merged_fst.df.loboos$Site1 = factor(neut.merged_fst.df.loboos$Site1, levels = unique(neut.merged_fst.df.loboos$Site1))
neut.merged_fst.df.loboos$Site2 = factor(neut.merged_fst.df.loboos$Site2, levels = unique(neut.merged_fst.df.loboos$Site2))

# Plot heatmap - with pops geographically ordered and FST values labelled
# (colours adjusted from blue-pink-red to approx match clawed lobster scale)
ggplot(data = neut.merged_fst.df.loboos, aes(x = Site1, y = Site2, fill = FST))+
  geom_tile(colour = "black")+
  geom_text(aes(label = FST), color="black", size = 4)+
  scale_fill_gradient(low = "deepskyblue", high = "red", name = fst.label, 
                      limits = c(0, 0.05), breaks = c(0, 0.01, 0.02, 0.03, 0.04, 0.05))+
  scale_x_discrete(expand = c(0,0))+
  scale_y_discrete(expand = c(0,0), position = "right")+
  theme(axis.text.y = element_text(colour = "black", size = 14), #face = "bold"),
        axis.text.x = element_text(colour = "black", size = 14, #face = "bold", 
                                   angle=90, vjust=0.5),
        axis.title = element_blank(),
        panel.grid = element_blank(),
        panel.background = element_blank(),
        legend.position = "right",
        legend.title = element_text(size = 16, face = "bold"),
        legend.text = element_text(size = 11)
  )

## Export plot
ggsave("Fst_PWheatmap_NeutralMerged_ATLOos.png", width=12, height=8, dpi=300)


#
# Replot heatmap - with pops geographically ordered but no FST value labels
# (colours adjusted from blue-pink-red to approx match clawed lobster scale)
ggplot(data = neut.merged_fst.df.loboos, aes(x = Site1, y = Site2, fill = FST))+
  geom_tile(colour = "black")+
  #  geom_text(aes(label = FST), color="black", size = 3)+
  scale_fill_gradient(low = "deepskyblue", high = "red", name = fst.label, 
                      limits = c(0, 0.05), breaks = c(0, 0.01, 0.02, 0.03, 0.04, 0.05))+
  scale_x_discrete(expand = c(0,0))+
  scale_y_discrete(expand = c(0,0), position = "right")+
  theme(axis.text.y = element_text(colour = "black", size = 16), #face = "bold"),
        axis.text.x = element_text(colour = "black", size = 16, #face = "bold", 
                                   angle=90, vjust=0.5),axis.title = element_blank(),
        panel.grid = element_blank(),
        panel.background = element_blank(),
        legend.position = "right",
        legend.title = element_text(size = 14, face = "bold"),
        legend.text = element_text(size = 10)
  )

## Export plot
ggsave("Fst_PWheatmap_NeutralMerged_GeoOrderNoLabels_vPubFig.png", width=11, height=10, dpi=300)




#
#===================================================================#
#

### Isolation By Distance Calculations

### First run it with all samples together - full SNP set (including outliers, and sites as sampled)

# Import Fst (from above) 

fst.df = read.csv("Fst-matrix_FullPWzeroed_188i6185s27p.csv", row.names = 1)
fst.df

# Import Seaward Pairwise Distances (covered in RDA script)

dist.df = read.csv("lc_distances_km.csv", row.names = 1)
dist.df

## Check column names are the same
colnames(fst.df)
colnames(dist.df)
colnames(fst.df) == colnames(dist.df)

#--------------#
#
# Mantel tests
#
#--------------#
  
## Convert to dist object
geodist = as.dist(dist.df)  ; geodist
fstWC = as.dist(fst.df) ; fstWC
# simple regression of genetic vs geographic distances
plot(fstWC ~ geodist)

# consult TJenksCode_differentiation_stats.R in this folder for:
# - editing minus numbers or NAs to zero
# - calculating global Fst
# - calculating 95%CIs and sig testing of pw Fst

#### Mantel test using all sites
man.full = mantel.rtest(geodist, fstWC, nrepet = 10000)
man.full

#Monte-Carlo test
#Call: mantelnoneuclid(m1 = m1, m2 = m2, nrepet = nrepet)
#
#Observation: 0.3203527 (R2 value)
#
#Based on 10000 replicates
#Simulated p-value: 0.04289571  (p-value)
#Alternative hypothesis: greater 
#
#Std.Obs   Expectation      Variance 
#2.379583e+00 1.579121e-05 1.812226e-02 

## Create labels for plots
fstlab = expression(italic("F")[ST])
r1 = round(man.full$obs,2)
p1 = format(round(man.full$pvalue, 3), nsmall=3)

## Create dataframe of distance matrices
df = data.frame(geodistance=as.vector(geodist),
                gendistance=as.vector(fstWC))  
# add column highlighting oosterschelde pw comparisons
df = mutate(df, Oos= ifelse(gendistance > 0.03 & geodistance < 2500, "Oosterschelde", "Other Sites"))
head(df)

### CHANGE R2 IN PLOT CODE TO x of 'OBSERVATION = x' FROM mantel.rtest 

## ggplot
IBDall=ggplot(data=df)+
   geom_point(aes(x=geodistance, y=gendistance, colour=Oos), size=3)+
   scale_colour_manual(values=c("Oosterschelde" = 'red', "Other Sites" = 'deepskyblue'))+
#  geom_smooth(aes(x=geodistance, y=gendistance), method="lm",
#              se=TRUE, level=0.95)+
  xlab("Geographic distance (km)")+
  ylab(fstlab)+
  #labs(title="All sites")+
#  geom_label(aes(label="r^2 == 0.32^'*'", x=3200,y=0.06),
#            # x=-Inf,y=Inf),
#             colour="black", size=5, label.padding=unit(0.25,"cm"),
#             label.size = 0.25, hjust=-0.1, vjust=1.2, parse=TRUE)+ 
  theme(
    axis.text.y = element_text(colour="black", size=13),
    axis.text.x = element_text(colour="black", size=13),
    axis.title.y = element_text(colour="black", size=15),
    axis.title.x = element_text(colour="black", size=14),
    # make legend title blank
    legend.title = element_blank(),
    panel.border = element_rect(colour="black", fill=NA, size=1),
    plot.title = element_text(hjust=0.5, size=20), # title centered 
    plot.margin = margin(5.5,13.5,5.5,5.5),
    plot.tag = element_text(size=20),
    legend.position = "top",
    legend.text = element_text(colour="black", size=13)
  )
IBDall

# save the ggplot as a png and pdf
#ggsave("IBDplot_AllSites_FullData.pdf", width = 12, height=7.5)
ggsave("IBDplot_AllSites_FullData.png", dpi=500, width=9, height=6)

###
### ----------------------------------------------------------
###


### Next - repeat IBD run it with samples merged where appropriate and ONLY neutral loci (required for IBD)

# Import Fst (from above) 

neutralmerged_fst.df = read.csv("Fst-matrix_FullPWzeroed_NeutralMerged_188i6154s13p.csv", row.names = 1)
neutralmerged_fst.df

# Import Seaward Pairwise Distances (covered in RDA script)

mergedsites_dist.df = read.csv("lc_distances_km_ATLOOS_mergedsitesK13.csv", row.names = 1)
mergedsites_dist.df

## Check column names are the same
colnames(neutralmerged_fst.df)
colnames(mergedsites_dist.df)
colnames(neutralmerged_fst.df) == colnames(mergedsites_dist.df)

#--------------#
#
# Mantel tests
#
#--------------#

## Convert to dist object
geodist_neut = as.dist(mergedsites_dist.df)  ; geodist_neut
fstWC_neut = as.dist(neutralmerged_fst.df) ; fstWC_neut
# simple regression of genetic vs geographic distances
plot(fstWC_neut ~ geodist_neut)
rsq <- function(x, y) summary(lm(y~x))$r.squared
rsq(fstWC_neut, geodist_neut)
#[1] 0.004747629


# consult TJenksCode_differentiation_stats.R in this folder for:
# - editing minus numbers or NAs to zero
# - calculating global Fst
# - calculating 95%CIs and sig testing of pw Fst

#### Mantel test using merged sites (k13) and only netural loci (6154 snps)
man.full_neut = mantel.rtest(geodist_neut, fstWC_neut, nrepet = 10000)
man.full_neut

#Monte-Carlo test
#Call: mantelnoneuclid(m1 = m1, m2 = m2, nrepet = nrepet)
#
#Observation: 0.06890304 (R2 value) NO - R2 is 0.0047
#
#Based on 10000 replicates
#Simulated p-value: 0.2822718   # Not significant overall - coz of hierarchical pattern maybe? re-run with/without Oos
#Alternative hypothesis: greater 
#
#Std.Obs Expectation    Variance 
#0.324445356 0.000200644 0.044839487 


## Create labels for plots
fstlab = expression(italic("F")[ST])
r1 = round(man.full_neut$obs,2)
p1 = format(round(man.full_neut$pvalue, 3), nsmall=3)

## Create dataframe of distance matrices
df_neut = data.frame(geodistance=as.vector(geodist_neut),
                gendistance=as.vector(fstWC_neut))  
# add column highlighting oosterschelde pw comparisons
df_neut = mutate(df_neut, Oos= ifelse(gendistance > 0.025 & geodistance < 2500, 
                                      "Pairs with Oosterschelde", "Pairs without Oosterschelde"))
head(df_neut)

### CHANGE R2 IN PLOT CODE TO x of 'OBSERVATION = x' FROM mantel.rtest 

## ggplot
IBDallneutralmerged=ggplot(data=df_neut)+
  geom_point(aes(x=geodistance, y=gendistance, colour=Oos), size=3)+
  scale_colour_manual(values=c("Pairs with Oosterschelde" = 'red', "Pairs without Oosterschelde" = 'deepskyblue'))+
  #  geom_smooth(aes(x=geodistance, y=gendistance), method="lm",
  #              se=TRUE, level=0.95)+
  xlab("Geographic distance (km)")+
  ylab(fstlab)+
  #labs(title="All sites")+
  #  geom_label(aes(label="r^2 == 0.32^'*'", x=3200,y=0.06),
  #            # x=-Inf,y=Inf),
  #             colour="black", size=5, label.padding=unit(0.25,"cm"),
  #             label.size = 0.25, hjust=-0.1, vjust=1.2, parse=TRUE)+ 
  theme(
    axis.text.y = element_text(colour="black", size=13),
    axis.text.x = element_text(colour="black", size=13),
    axis.title.y = element_text(colour="black", size=15),
    axis.title.x = element_text(colour="black", size=14),
    # make legend title blank
    legend.title = element_blank(),
    panel.border = element_rect(colour="black", fill=NA, size=1),
    plot.title = element_text(hjust=0.5, size=20), # title centered 
    plot.margin = margin(5.5,13.5,5.5,5.5),
    plot.tag = element_text(size=20),
    legend.position = "top",
    legend.text = element_text(colour="black", size=13)
  )
IBDallneutralmerged

# save the ggplot as a png and pdf
#ggsave("IBDplot_AllSites_FullData.pdf", width = 12, height=7.5)
ggsave("IBDplot_MergedSites-13p_NeutralLoci-6154s.png", dpi=500, width=9, height=6)

# ------------------------------------------------------------
# check mantel tests for IBD with and without Oosterschelde...

# first up, IBD without Oos...

# Import Fst table  

neutralmerged_NoOos_fst.df = read.csv("Fst-matrix_FullPWzeroed_NeutralMerged_NoOos_181i6154s12p.csv", row.names = 1)
neutralmerged_NoOos_fst.df

# Import Seaward Pairwise Distances (covered in RDA script)

mergedsites_NoOos_dist.df = read.csv("lc_distances_km_ATLOOS_NoOos_mergedsitesK13.csv", row.names = 1)
mergedsites_NoOos_dist.df

## Check column names are the same
colnames(neutralmerged_NoOos_fst.df)
colnames(mergedsites_NoOos_dist.df)
colnames(neutralmerged_NoOos_fst.df) == colnames(mergedsites_NoOos_dist.df)

#--------------#
#
# Mantel tests
#
#--------------#

## Convert to dist object
geodist_neut_NoOos = as.dist(mergedsites_NoOos_dist.df)  ; geodist_neut_NoOos
fstWC_neut_NoOos = as.dist(neutralmerged_NoOos_fst.df) ; fstWC_neut_NoOos
# simple regression of genetic vs geographic distances
plot(fstWC_neut_NoOos ~ geodist_neut_NoOos)
rsq <- function(x, y) summary(lm(y~x))$r.squared
rsq(fstWC_neut_NoOos, geodist_neut_NoOos)
#[1]  0.4060828


#### Mantel test using merged sites (k13) and only netural loci (6154 snps)
man.full_neut_NoOos = mantel.rtest(geodist_neut_NoOos, fstWC_neut_NoOos, nrepet = 10000)
man.full_neut_NoOos

#
#Monte-Carlo test
#Call: mantelnoneuclid(m1 = m1, m2 = m2, nrepet = nrepet)

#Observation: 0.6372463 (R2) - NOO!!!! THIS IS NOT R2 value!!!!

#Based on 10000 replicates
#Simulated p-value: 0.00059994          # All sites IBD is highly sig positive without Oos pairs...
#Alternative hypothesis: greater 

#Std.Obs  Expectation     Variance 
#3.2801866476 0.0003503184 0.0376998702 

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#

# next up, IBD with ONLY Oos...?! 

# Import Fst table - 12 values cannot make a matrix, so two ommitted at random in v1 / v2 / v3 (max 1 missing per pair)
# then take a mean of the three results...

# Run1
neutralmerged_OnlyOos1_fst.df = read.csv("OosPWgendist1.csv", row.names = 1)
neutralmerged_OnlyOos1_fst.df

# Import Seaward Pairwise Distances (covered in RDA script)

mergedsites_OnlyOos1_dist.df = read.csv("OosPWgeodist1.csv", row.names = 1)
mergedsites_OnlyOos1_dist.df

# Mantel tests
#--------------#

## Convert to dist object
geodist_neut_OnlyOos1 = as.dist(mergedsites_OnlyOos1_dist.df)  ; geodist_neut_OnlyOos1
fstWC_neut_OnlyOos1 = as.dist(neutralmerged_OnlyOos1_fst.df) ; fstWC_neut_OnlyOos1

# simple regression of genetic vs geographic distances
plot(fstWC_neut_OnlyOos1 ~ geodist_neut_OnlyOos1)
rsq <- function(x, y) summary(lm(y~x))$r.squared
rsq(fstWC_neut_OnlyOos1, geodist_neut_OnlyOos1)
#[1] 0.4243443

#### Mantel test using merged sites (k13) and only netural loci (6154 snps)
man.full_neut_OnlyOos1 = mantel.rtest(geodist_neut_OnlyOos1, fstWC_neut_OnlyOos1, nrepet = 10000)
man.full_neut_OnlyOos1

#
#Monte-Carlo test
#Call: mantelnoneuclid(m1 = m1, m2 = m2, nrepet = nrepet)

#Observation: 0.6514171 

#Based on 10000 replicates
#Simulated p-value: 0.02539746 
#Alternative hypothesis: greater 

#Std.Obs  Expectation     Variance 
#2.060143689 -0.001662443  0.100493318

### ----------------------------------------------------------
###

# Run2
neutralmerged_OnlyOos2_fst.df = read.csv("OosPWgendist2.csv", row.names = 1)
neutralmerged_OnlyOos2_fst.df

# Import Seaward Pairwise Distances (covered in RDA script)

mergedsites_OnlyOos2_dist.df = read.csv("OosPWgeodist2.csv", row.names = 1)
mergedsites_OnlyOos2_dist.df

# Mantel tests
#--------------#

## Convert to dist object
geodist_neut_OnlyOos2 = as.dist(mergedsites_OnlyOos2_dist.df)  ; geodist_neut_OnlyOos2
fstWC_neut_OnlyOos2 = as.dist(neutralmerged_OnlyOos2_fst.df) ; fstWC_neut_OnlyOos2

# simple regression of genetic vs geographic distances
plot(fstWC_neut_OnlyOos2 ~ geodist_neut_OnlyOos2)
rsq <- function(x, y) summary(lm(y~x))$r.squared
rsq(fstWC_neut_OnlyOos2, geodist_neut_OnlyOos2)
#[1] 0.3396345

#### Mantel test using merged sites (k13) and only netural loci (6154 snps)
man.full_neut_OnlyOos2 = mantel.rtest(geodist_neut_OnlyOos2, fstWC_neut_OnlyOos2, nrepet = 10000)
man.full_neut_OnlyOos2

#
#Monte-Carlo test
#Call: mantelnoneuclid(m1 = m1, m2 = m2, nrepet = nrepet)

#Observation: 0.5827817 

#Based on 10000 replicates
#Simulated p-value: 0.07739226 
#Alternative hypothesis: greater 

#Std.Obs Expectation    Variance 
#1.806298610 0.002980349 0.103033705 
###



### ----------------------------------------------------------

# Run3
neutralmerged_OnlyOos3_fst.df = read.csv("OosPWgendist3.csv", row.names = 1)
neutralmerged_OnlyOos3_fst.df

# Import Seaward Pairwise Distances (covered in RDA script)

mergedsites_OnlyOos3_dist.df = read.csv("OosPWgeodist3.csv", row.names = 1)
mergedsites_OnlyOos3_dist.df

# Mantel tests
#--------------#

## Convert to dist object
geodist_neut_OnlyOos3 = as.dist(mergedsites_OnlyOos3_dist.df)  ; geodist_neut_OnlyOos3
fstWC_neut_OnlyOos3 = as.dist(neutralmerged_OnlyOos3_fst.df) ; fstWC_neut_OnlyOos3

# simple regression of genetic vs geographic distances
plot(fstWC_neut_OnlyOos3 ~ geodist_neut_OnlyOos3)
rsq <- function(x, y) summary(lm(y~x))$r.squared
rsq(fstWC_neut_OnlyOos3, geodist_neut_OnlyOos3)
#[1] 0.4827979

#### Mantel test using merged sites (k13) and only netural loci (6154 snps)
man.full_neut_OnlyOos3 = mantel.rtest(geodist_neut_OnlyOos3, fstWC_neut_OnlyOos3, nrepet = 10000)
man.full_neut_OnlyOos3

#
#Monte-Carlo test
#Call: mantelnoneuclid(m1 = m1, m2 = m2, nrepet = nrepet)

#Observation: 0.6948366 

#Based on 10000 replicates
#Simulated p-value: 0.0419958 
#Alternative hypothesis: greater 

#Std.Obs Expectation    Variance 
#2.181001234 0.001848525 0.100957763 

### ----------------------------------------------------------

### ----------------------------------------------------------

# Run4
neutralmerged_OnlyOos4_fst.df = read.csv("OosPWgendist4.csv", row.names = 1)
neutralmerged_OnlyOos4_fst.df

# Import Seaward Pairwise Distances (covered in RDA script)

mergedsites_OnlyOos4_dist.df = read.csv("OosPWgeodist4.csv", row.names = 1)
mergedsites_OnlyOos4_dist.df

# Mantel tests
#--------------#

## Convert to dist object
geodist_neut_OnlyOos4 = as.dist(mergedsites_OnlyOos4_dist.df)  ; geodist_neut_OnlyOos4
fstWC_neut_OnlyOos4 = as.dist(neutralmerged_OnlyOos4_fst.df) ; fstWC_neut_OnlyOos4

# simple regression of genetic vs geographic distances
plot(fstWC_neut_OnlyOos4 ~ geodist_neut_OnlyOos4)
rsq <- function(x, y) summary(lm(y~x))$r.squared
rsq(fstWC_neut_OnlyOos4, geodist_neut_OnlyOos4)
#[1] 0.002983145

#### Mantel test using merged sites (k13) and only netural loci (6154 snps)
man.full_neut_OnlyOos4 = mantel.rtest(geodist_neut_OnlyOos4, fstWC_neut_OnlyOos4, nrepet = 10000)
man.full_neut_OnlyOos4

#
#Monte-Carlo test
#Call: mantelnoneuclid(m1 = m1, m2 = m2, nrepet = nrepet)

#Observation: 0.05461817 

#Based on 10000 replicates
#Simulated p-value: 0.3863614 
#Alternative hypothesis: greater 

#Std.Obs Expectation    Variance 
#0.274239250 0.001673889 0.037271673

### ----------------------------------------------------------

### ----------------------------------------------------------

# Run5
neutralmerged_OnlyOos5_fst.df = read.csv("OosPWgendist5.csv", row.names = 1)
neutralmerged_OnlyOos5_fst.df

# Import Seaward Pairwise Distances (covered in RDA script)

mergedsites_OnlyOos5_dist.df = read.csv("OosPWgeodist5.csv", row.names = 1)
mergedsites_OnlyOos5_dist.df

# Mantel tests
#--------------#

## Convert to dist object
geodist_neut_OnlyOos5 = as.dist(mergedsites_OnlyOos5_dist.df)  ; geodist_neut_OnlyOos5
fstWC_neut_OnlyOos5 = as.dist(neutralmerged_OnlyOos5_fst.df) ; fstWC_neut_OnlyOos5

# simple regression of genetic vs geographic distances
plot(fstWC_neut_OnlyOos5 ~ geodist_neut_OnlyOos5)
rsq <- function(x, y) summary(lm(y~x))$r.squared
rsq(fstWC_neut_OnlyOos5, geodist_neut_OnlyOos5)
#[1]  0.359788

#### Mantel test using merged sites (k13) and only netural loci (6154 snps)
man.full_neut_OnlyOos5 = mantel.rtest(geodist_neut_OnlyOos5, fstWC_neut_OnlyOos5, nrepet = 10000)
man.full_neut_OnlyOos5

#
#Monte-Carlo test
#Call: mantelnoneuclid(m1 = m1, m2 = m2, nrepet = nrepet)

#Observation: 0.5998233 

#Based on 10000 replicates
#Simulated p-value: 0.0489951 
#Alternative hypothesis: greater 

#Std.Obs Expectation    Variance 
#1.928185589 0.001417343 0.096315059 


### ----------------------------------------------------------

### ----------------------------------------------------------

# Run6
neutralmerged_OnlyOos6_fst.df = read.csv("OosPWgendist6.csv", row.names = 1)
neutralmerged_OnlyOos6_fst.df

# Import Seaward Pairwise Distances (covered in RDA script)

mergedsites_OnlyOos6_dist.df = read.csv("OosPWgeodist6.csv", row.names = 1)
mergedsites_OnlyOos6_dist.df

# Mantel tests
#--------------#

## Convert to dist object
geodist_neut_OnlyOos6 = as.dist(mergedsites_OnlyOos6_dist.df)  ; geodist_neut_OnlyOos6
fstWC_neut_OnlyOos6 = as.dist(neutralmerged_OnlyOos6_fst.df) ; fstWC_neut_OnlyOos6

# simple regression of genetic vs geographic distances
plot(fstWC_neut_OnlyOos6 ~ geodist_neut_OnlyOos6)
rsq <- function(x, y) summary(lm(y~x))$r.squared
rsq(fstWC_neut_OnlyOos6, geodist_neut_OnlyOos6)
#[1] 0.4336917

#### Mantel test using merged sites (k13) and only netural loci (6154 snps)
man.full_neut_OnlyOos6 = mantel.rtest(geodist_neut_OnlyOos6, fstWC_neut_OnlyOos6, nrepet = 10000)
man.full_neut_OnlyOos6

#
#Monte-Carlo test
#Call: mantelnoneuclid(m1 = m1, m2 = m2, nrepet = nrepet)

#Observation: 0.6585527 

#Based on 10000 replicates
#Simulated p-value: 0.05919408 
#Alternative hypothesis: greater 

#Std.Obs Expectation    Variance 
#1.724743957 0.005945316 0.143170892 

### ----------------------------------------------------------

# Only Oosterschelde - mean Mantels with two missing values 

#     v1      v2     v3     mean (x)
#p = 0.009  0.017  0.052    p=0.026    (p<0.05)
#r2= 0.368  0.411  0.421    r=



####################################################################################################################



### Calculate effective population size (Ne)
citation("dartR")
dartR::gl.install.vanilla.dartR()

# Load packages 
library(adegenet)
library(stringr)
library(dartR)
library(poppr)

# install qvalue & SNPrelate, as dependencies of OUTflank / dartR
if (!require("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

BiocManager::install("qvalue")
library(qvalue)

BiocManager::install("SNPRelate")
library(SNPRelate)


# Outflank not installed directly in version 4.0; run via dartR (gl.outlfank, etc)
devtools::install_github("whitlock/OutFLANK")
library(OutFLANK)
#install.packages("Rtools")
#library(Rtools)


# NeEstimator v2.1 downloaded from website and Ne2-1.exe file copied into source folder
# To avoid Wahlund effects, we can't test structured metapopulations
# So we want to use the neutral dataset!!!
# Even Atlantic cline could be an issue - so best to run this on regional subsets
# Also worth running on TJ 79 SNP subset data, as sample sizes for RAD are too small really


# Ne 1) first try using the merged sites neutral dataset...

# First convert genind to genlight object
ne_gl <- gi2gl(neutral.merged)
ne_gl

# Run NeEstimator V2.1 - output data goes into Ne Estimator subfolder...
ne_neutralmerged <- dartR::gl.LDNe(ne_gl,
                         outfile = "ATLoos_NeutralMerged_LDNE.txt",
                         outpath = "./NeEstimatorv2x1",
                         neest.path = "./NeEstimatorv2x1",
                         critical = c(0.01, 0.02, 0.05),
                         singleton.rm = TRUE,
                         mating = "random"
)

write.csv(ne_neutralmerged, file="Ne_NeutralMerged_13pops6154RADsnps_dartR.csv")

# interesting result: Estimated Ne appears to be ~68 with confidence intervals of ~63-83..?

summary(neutral.merged$pop)









load("NeutralData_188i6154s27p.RData")
neutral.ATLoos
summary(neutral.ATLoos$pop)

#?popsub

#create Oosterschelde only RADseq genind, using sublist ('keep these pops')
data_oos = popsub(neutral.ATLoos, sublist = c("Oos"))
data_oos

# now create a genind with Oos and surrounding pops for Ne comparison (all loci)

data_nsea = popsub(neutral.ATLoos, sublist = c("Oos","Hel","Sbs","Cro","Brd","Eye","Lys","Flo","Ber"))
data_nsea
summary(data_nsea$pop)
#66 inds, 9 pops, 6154 loci



#Then run these geninds one at a time to calculate Ne...

# First convert genind to genlight object
ne_oos <- gi2gl(data_oos)
ne_oos

# Run NeEstimator V2.1 - output data goes into Ne Estimator subfolder...
ne.oos <- dartR::gl.LDNe(ne_oos,
              outfile = "oosRAD-LDNE.txt",
              outpath = "./NeEstimatorv2x1",
              neest.path = "./NeEstimatorv2x1",
              critical = c(0.01, 0.02, 0.05),
              singleton.rm = TRUE,
              mating = "random"
)


# interesting result: Estimated Ne appears to be ~68 with confidence intervals of ~63-83..?


# Now try with Oosterschelde and surrounding samples
# First convert genind to genlight object
gl_nsea <- gi2gl(data_nsea)
gl_nsea

# Run NeEstimator V2.1 - output data goes into Ne Estimator subfolder...
ne.nsea <- dartR::gl.LDNe(gl_nsea,
                         outfile = "nseaRAD-LDNE.txt",
                         outpath = "./NeEstimatorv2x1",
                         neest.path = "./NeEstimatorv2x1",
                         critical = c(0.01, 0.02, 0.05),
                         singleton.rm = TRUE,
                         mating = "random"
)

ne.nsea

write.csv(ne.nsea, file="Ne_NorthSea_6185RADsnps_dartR.csv")



###
# Try estimating the Ne now using Tjenks Fluidigm SNPs with the Full 96-SNP Sample set... (less SNPs but more inds per sample)

# load genind
load("lobster_1489ind_79snps_51pop.RData")
data_tj <- data_filt
data_tj
summary(data_tj$pop)

# check for overlapping MLGs that may indicate duplicated samples
## Check for 
#?mlg
mlg(data_tj)
# 1489 individuals but 1482 genotypes unique - so 7x overlapping
genoIDs = mlg.id(data_tj) ; genoIDs
for (i in genoIDs){ # for each element in the list genoIDs
  if (length(genoIDs[i]) > 1){ # if the length is greater than two
    print(i) # print individuals that are duplicates
  }
}

## Remove duplicated genotypes! 
# (no need to worry about Americanus, but Eyemouth Ne tested will be biased by dups)
dups = c("Eye32","Eye35","Eye38","Eye40","Eye41","Eye42")

indnames = indNames(data_tj) # individuals names
nodups = indnames[! indnames %in% dups] # remove dups from vector
nodups
(data_tj79 = data_tj[nodups, ]) # new genind object without duplicates
mlg(data_tj79) # re-check for duplicates

# one duplicated American genotype (about to be filtered out) 
# All European lobster MLGs are unique

#create new genind featuring just the North Sea samples we want to calculate Ne for
data_panelNsea = popsub(gid = data_tj79, sublist= c("Brd","Cro","Eye","Sbs","Ber","Flo","Lys", "Hel","Oos"))

data_panelNsea
nPop(data_panelNsea)
summary(data_panelNsea$pop)
# 313 inds, 79 SNPs, 16 pops, samplesize = 26-40

# First convert genind to genlight object
gl_panelNS <- gi2gl(data_panelNsea)
gl_panelNS

?gl.LDNe
# Run NeEstimator V2.1 with minor allele cutoff of 0.00 (all loci) - output data goes into Ne Estimator subfolder...
ne.panel <- dartR::gl.LDNe(gl_panelNS,
                         outfile = "TJpanelNSea_RAD-LDNE.txt",
                         outpath = "./NeEstimatorv2x1",
                         neest.path = "./NeEstimatorv2x1",
                         critical = c(0.01, 0.02, 0.05),
                         singleton.rm = TRUE,
                         mating = "random")

ggsave("Ne_NorthSea_79snps.png", dpi=350, width=12, height=7.5)
ne.panel

write.csv(ne.panel, file="Ne_NorthSea_79TJsnps_dartR.csv")

##################

# and again but this time with just TJs 71 neutral SNPs (removing 8 outliers) 

locname = locNames(data_panelNsea) ; locname # locus names

loc2remove = c("11291","15581","32358","42395",
               "65064","53935","58053","65576") # 8 outliers 
locname = locname[! locname %in% loc2remove] ;locname # 71 neutral loci only
data_TJ71.NSea = data_panelNsea[loc=locname] # new genind dataset with only neutral SNPs

data_TJ71.NSea
nPop(data_TJ71.NSea)
summary(data_TJ71.NSea$pop)
  # 3 inds, 71 SNPs, 9 pops, samplesize = 26-40 (6x Eyemouth dups now removed)

# First convert genind to genlight object
gl_TJ71NS <- gi2gl(data_TJ71.NSea)
gl_TJ71NS

?gl.LDNe
# Run NeEstimator V2.1 with minor allele cutoff of 0.01/0.05 - output data goes into Ne Estimator subfolder...
ne.TJ71NS <- dartR::gl.LDNe(gl_TJ71NS,
                           outfile = "TJ71neut-NSea_LDNE.txt",
                           outpath = "./NeEstimatorv2x1",
                           neest.path = "./NeEstimatorv2x1",
                           critical = c(0.01, 0.05),
                           singleton.rm = TRUE,
                           mating = "random")

ggsave("Ne_NorthSea_71snps.png", dpi=350, width=12, height=7.5)

write.csv(ne.TJ71NS, file="Ne_NorthSea_71neutralTJsnps_dartR.csv")







######################## Calculate Popwise FIS

install.packages("dartR")

# reload data_filt RAD SNPs dataset in case... 
load("ATLoos_fullpoly_188i-6185s-27p.RData")
data_filt

# convert genind to SNP object for dartR - first up, the full RAD SNPs dataset
SNPdata_full <- gi2gl(data_filt)
#run dartR's heterozygosity and FIS report...
?gl.report.heterozygosity

# Ho = Observed heterozygosity (Ho) 
# Unbiased expected heterozygosity (uHe) = He * (2*n_Ind / (2*n_Ind -1))
### (where n_Ind is the number of individuals without missing data)
# Inbreeding coefficient (FIS) calculated as = 1 - (mean(Ho) / mean(uHe))

gl.report.heterozygosity(SNPdata_full)
# save plot generated 
ggsave("HetFIS-popwise_RAD6185snps.png", width=20, height=10, dpi=300)
# manually copy and save table in console into excel etc

# Recheck popwise private alleles (this is loci / pop, not alleles /pop as previous)
#library(networkD3)
#gl.report.pa(SNPdata_full)

# calculate population alpha and beta diversity
#gl.report.diversity(SNPdata_full)


# convert genind to SNP object for dartR - first up, the full RAD SNPs dataset
SNPdata_neut <- gi2gl(neutral.ATLoos)
#run dartR's heterozygosity and FIS report...
?gl.report.heterozygosity

# Ho = Observed heterozygosity (Ho) 
# Unbiased expected heterozygosity (uHe) = He * (2*n_Ind / (2*n_Ind -1))
### (where n_Ind is the number of individuals without missing data)
# Inbreeding coefficient (FIS) calculated as = 1 - (mean(Ho) / mean(uHe))

gl.report.heterozygosity(SNPdata_neut)
# save plot generated 
ggsave("HetFIS-popwise_RAD6154snps_27p.png", width=20, height=10, dpi=300)
# manually copy and save table in console into excel etc



### and again with the sites merged neutral dataset

SNPdata_neut.merged <- gi2gl(neutral.merged)
gl.report.heterozygosity(SNPdata_neut.merged)










# next up, the Fluidigm SNPs dataset - fewer loci but more invididuals for popwise estimates
load("lobster_1489ind_79snps_51pop.RData")
data_filt
data_tjsnps <- data_filt
data_tjsnps
summary(data_tjsnps$pop)

# remove pops which are too small or not useful (med / american / hybrids etc)
data_tjsnps <- popsub(data_tjsnps, exclude = c("Adr", "Ale", "Amer", "Tor", 
                                               "Chi", "Ion", "Laz", "Sky", 
                                               "Tar", "The", "AmerCook", 
                                               "EuroCook", "HybridX", "Aeg19",
                                               "Sar13", "Sar17","Csa",
                                               "Idr17","Bre", "Tro")) 

# note that when running this dataset without removing these pops, 
# it becomes apparent that although higher FIS values are generally indicative
# of greater relatedness  among a pop sample than would be expected by chance,
# and lower FIS values indicate lower average relatedness in a pop, strongly
# NEGATIVE FIS values indicates fewer homozygotes than anticipated by random recombination, 
# so can also be interesting - in my case, the hybrids (all full sibs so fully related)
# come out as VERY strongly NEGATIVE FIS: -0.34! The only other pops which have 
# FIS <-0.05 are Laz and Tar, both very small sample sizes (n=5)

summary(data_tjsnps$pop)
# Yep - that looks better - Trondheim and Brest removed (n= 17 & 21, resp) 
# Keep only IDR16, larger of two separate temporal replicates 
# rename IDR
popNames(data_tjsnps) = gsub("Idr16", "Idr", popNames(data_tjsnps))

#need to be careful here, as 79 SNP dataset overrides RAD snps as data_filt
# reload data_filt RAD SNPs dataset in case... 
load("ATLoos_fullpoly_188i-6185s-27p.RData")
data_filt

SNPdata_tj79 <- gi2gl(data_tjsnps)
#run dartR's heterozygosity and FIS report...
#?gl.report.heterozygosity
gl.report.heterozygosity(SNPdata_tj79)
# save plot generated 
ggsave("HetFIS-popwise_tj79snps.png", width=20, height=10, dpi=300)
# manually copy and save table in console into excel etc
# again, Oosterschelde is middle of the road here

#lastly, check what we get with neutral vs outlier RAD SNPs
neutral.ATLoos
# convert genind to SNP object for dartR - just neutral RAD SNPs dataset
SNPdata_neut <- gi2gl(neutral.ATLoos)
#run dartR's heterozygosity and FIS report...
gl.report.heterozygosity(SNPdata_neut)
# save plot generated 
ggsave("HetFIS-popwise_RADneut6154snps.png", width=20, height=10, dpi=300)
# manually copy and save table in console into excel etc



outlier_data
# convert genind to SNP object for dartR - just outlier RAD SNPs dataset
SNPdata_out <- gi2gl(outlier_data)
#run dartR's heterozygosity and FIS report...
gl.report.heterozygosity(SNPdata_out)
# save plot generated 
ggsave("HetFIS-popwise_RADoutlier31snps.png", width=20, height=10, dpi=300)
# manually copy and save table in console into excel etc


#################################################################################################

# missing data at these loci make the Trondheim sample fail AR calculation, 
# remove and re-run 

load("NeutralData_188i6154s27p.RData")
neutral.ATLoos

# Calculate allele frequencies for each site
allele_freqs = data.frame(rraf(neutral.ATLoos, by_pop=TRUE, correction = FALSE), check.names = FALSE)

# Keep only the first of the two alleles for each SNP (since p=1-q).
allele_freqs = allele_freqs[, seq(1, dim(allele_freqs)[2], 2)]
head(allele_freqs)

# Identify and remove loci with no data for a whole population (causes failure of Allelic Richness calculation for TRO)
which(is.na(allele_freqs), arr.ind=TRUE)

#row  col
#Tro  26 2649
#Tro  26 3212
#Tro  26 3245
#Tro  26 4982

# alter max.print to just show start/end 
# then I can see which locus IDs are in these columns positions
options(max.print=5000)
locid = locNames(neutral.ATLoos) ; locid

# col 2649 = locus "18575_157"
# col 3212 = locus "23321_245"
# col 3245 = locus "23513_95"
# col 4982 = locus "39470_118"

snps_to_remove = c("18575_157","23321_245","23513_95","39470_118")
locid = locid[! locid %in% snps_to_remove] ;locid # filtered loci
neutral.ATLoos_allpops = neutral.ATLoos[loc=locid] 
neutral.ATLoos_allpops
# 4 loci with missing data for all Tro samples successfully removed :) 

# rerun dartR basic stats
neutral_allpopsgl <- gi2gl(neutral.ATLoos_allpops)
gl.report.heterozygosity(neutral_allpopsgl)

# Calculate basic stats inc missing Tro AR using hierfstat
neutralstats_allpops = basic.stats(neutral.ATLoos_allpops, diploid = TRUE)
neutralstats_allpops

# show mean allelic richness per site across all loci, now finally inclusing missing Tro measure!
allelic.richness(genind2hierfstat(neutral.ATLoos_allpops))$Ar %>%
  apply(MARGIN = 2, FUN = mean) %>% 
  round(digits = 3)


