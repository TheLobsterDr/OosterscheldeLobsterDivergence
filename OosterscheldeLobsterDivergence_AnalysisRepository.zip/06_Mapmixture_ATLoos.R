# ----------------- #
#
# 6. Mapmixture for all European lobster samples across neutral SNP loci, with undifferentiated adjacent pops merged as regional samples
#
# Package by Tom Jenkins (t.l.jenkins@exeter.ac.uk). Code by Charlie Ellis (c.ellis@exeter.ac.uk)
#
# From "Genetic divergence and adaptation of an isolated European lobster population in the Netherlands", ICES JMS 2024,
# by CD Ellis, JR Paris, TL Jenkins, MR van Stralen, NA Steins, J Schotanus, JR Stevens.
#
# ----------------- #

# In RStudio set working directory to the path where this R script is located
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# clear Global Environment
rm(list=ls(all=TRUE))

# install.packages("devtools")
#devtools::install_github("Tom-Jenkins/mapmixture")

# Load package
library(mapmixture)
library(ggplot2)
library(sf)
library(tibble)


### ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ ###
### #################################################################################################### ###
### ==================================================================================================== ###

# Repeat this to produce publication figure with K3 Neutral data
# and only including N European sites to explore ancestry

# Read in admixture file format 1 (Snapclust K3 data)
admixture_neut_K3.p11 <- read.csv("Snapclust_K3_NeutralMerged_WithNoTanIber_P-Memberships.csv")
admixture_neut_K3.p11
summary(admixture_neut_K3.p11)

# Read in coordinates file
coordinates <- read.csv("coordinates_ATLOOS_mergedsites_11pops.csv")
coordinates

# Run basic mapmixture
map1_neut <- mapmixture(admixture_neut_K3.p11, coordinates, crs = 3035)
map1_neut
# very cool,save this manually from plot window (Export > png)
# could just do with pie chart colours as per PCA, and larger text etc...


# Run mapmixture with more advanced customisation
map2_neut_k3p11 <- mapmixture(admixture_neut_K3.p11, coordinates,
                        cluster_cols = c("dodgerblue","cyan","red"),
                        cluster_names = c("Cluster1","Cluster2","Cluster3"),
                        crs = 3035,
                        boundary = c(xmin=-12, xmax=15, ymin=45, ymax=65),
                        pie_size = 1,
)+
  # # Add additional label to the map
  # annotate("label",
  #          x = -10,
  #          y = 46.5,
  #          label = "Atlantic Ocean",
  #          size = 3,
  # )+
  # # Add additional text to the map
  # annotate("text",
  #          x = 2.5,
  #          y = 57,
#          label = "North Sea",
#          size = 3,
# )+
# Adjust ggplot theme options
theme(
  axis.title = element_text(size = 16),
  axis.text = element_text(size = 14),
  legend.position = "top",
  legend.text = element_text(size=15),
  legend.key.size = unit(0.7,"cm"),
  legend.box.spacing = unit(0, "cm")
)+
  # Adjust the size of the legend keys
  guides(fill = guide_legend(override.aes = list(size = 5, alpha = 1)))

map2_neut_k3p11
# nice! love this!! save manually as image .png 

#> Scale on map varies by more than 10%, scale bar may be inaccurate

# lastly, adjust scale for a higher res output for pub figure...

?mapmixture

# Define text coordinates
# mapmixture::transform_bbox(c(xmin = 3, xmax = 3, ymin =53, ymax = 53), 3035)



# Create a new point data frame, convert to sf object and then transform to CRS
text_df <- tibble(
  Label = c("Oos","Hel", "SKAG", "NORW", "SCOT", "EAGB", "EIRE", "IRIS", "CORN", "FRAN", "CHAN"),
  Lon = c(3.1, 7, 8, 4, -5, 0.5, -11.9, -4.9, -7.8, -5.2, -3.2),
  Lat = c(52.6, 55, 57.6, 63.2, 59.7, 55.3, 53, 54, 50, 46.7, 49.5)
)
text_sf <- st_transform(st_as_sf(text_df, coords = c("Lon","Lat"), crs = 4326), crs = 3035)
text_sf

# Run mapmixture with more advanced customisation
map3_neut_k3p11 <- mapmixture(admixture_neut_K3.p11, coordinates,
                        cluster_cols = c("dodgerblue","cyan","red"),
                        cluster_names = c("Cluster1","Cluster2","Cluster3"),
                        crs = 3035,
                        boundary = c(xmin=-12, xmax=16, ymin=45, ymax=63),
                        pie_size = 1,
                        scalebar_size = 2,
                        arrow_size = 2,
)+
  # Adjust ggplot theme options
  theme(
    axis.title = element_text(size = 16),
    axis.text = element_text(size = 13),
    legend.position = "top",
    legend.text = element_text(size=16),
    legend.key.size = unit(1,"cm"),
    legend.box.spacing = unit(0, "cm")
)+
  # Add text sf object to map
  geom_sf_text(data = text_sf, aes(label = Label), fontface= 'bold' )+     # for plain black text on map
 # geom_sf_label(data = text_sf, aes(label = Label))+   # alternative for text labels in white boxes 

  # Adjust the size of the legend keys
  guides(fill = guide_legend(override.aes = list(size = 5, alpha = 1)))

map3_neut_k3p11
# nice! love this!!

## Export plot

# save as .png
ggsave("Mapmixture_NeutralMerged_K3p11_Fig4.png", width=7, height=7, dpi=400)
# for some reason, ggsave() extends the lines of pie segments too big!

# alternate .png save code... this gets rid of the overlying pie plot hands!! 
png("Mapmixture_NeutralMerged_K3p11_Fig4.png", width = 7, height = 7, units = "in", res = 600)
map3_neut_k3p11
dev.off()
# that's better! 

# and save as a PDF (recommended for better integrity of map files anyway...)
ggsave(plot=map3_neut_k3p11, "Mapmixture_NeutralMerged_K3p11_Fig4.pdf", width=7, height=7)

# alternate .pdf save code... this gets rid of the overlying pie plot hands!! 
pdf("Mapmixture_NeutralMerged_K3p11_Fig4.pdf", width = 7, height = 7)
map3_neut_k3p11
dev.off()
# that's better! 

### ==================================================================================================== ###


# END